import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import app as airpocalypse


class AirpocalypsePageTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp_dir = tempfile.TemporaryDirectory()
        cls.original_data_dir = airpocalypse.DATA_DIR
        cls.original_database_path = airpocalypse.DATABASE_PATH
        airpocalypse.DATA_DIR = Path(cls.temp_dir.name)
        airpocalypse.DATABASE_PATH = airpocalypse.DATA_DIR / "test.sqlite3"
        airpocalypse.initialize_database()
        airpocalypse.app.config.update(TESTING=True)

    @classmethod
    def tearDownClass(cls):
        airpocalypse.DATA_DIR = cls.original_data_dir
        airpocalypse.DATABASE_PATH = cls.original_database_path
        cls.temp_dir.cleanup()

    def setUp(self):
        self.client = airpocalypse.app.test_client()

    def test_all_pages_render(self):
        for path in ("/", "/map", "/simulator", "/scenarios", "/sources"):
            with self.subTest(path=path):
                response = self.client.get(path)
                self.assertEqual(response.status_code, 200)
                self.assertIn(b"AIRPOCALYPSE", response.data)

    def test_overview_and_map_start_in_loading_state(self):
        for path in ("/", "/map"):
            with self.subTest(path=path):
                response = self.client.get(path)
                self.assertIn(b'class="page-container is-data-loading"', response.data)
                self.assertIn(b'data-page-loading="true"', response.data)
                self.assertIn(b'aria-busy="true"', response.data)

    def test_dashboard_does_not_fill_missing_readings(self):
        response = self.client.get("/")
        self.assertIn(b"No monitoring data has been connected yet", response.data)
        self.assertIn(b"No reading available", response.data)
        self.assertIn(b"Loading Open-Meteo history", response.data)
        self.assertIn(b"id=\"overview-source\"", response.data)
        self.assertIn(b'value="open-meteo" selected', response.data)
        self.assertIn(b"LOADING OPEN-METEO", response.data)
        self.assertIn(b"WAQI station median", response.data)
        self.assertIn(b"MODELED HISTORY", response.data)
        self.assertIn(b">90D</a>", response.data)

    def test_map_starts_without_invented_station_locations(self):
        response = self.client.get("/map")
        self.assertIn(b"No verified stations to display", response.data)
        self.assertIn(b"no heatmap or interpolated citywide values", response.data)
        self.assertEqual(self.client.get("/map-data").get_json(), {"stations": []})

    def test_waqi_map_source_requires_server_credential(self):
        saved_token = os.environ.pop("WAQI_API_TOKEN", None)
        try:
            waqi = self.client.get("/api/map/waqi-stations?south=30.6&west=76.6&north=30.9&east=76.9")
            self.assertEqual(waqi.status_code, 503)
            self.assertIn("WAQI_API_TOKEN", waqi.get_json()["error"])
        finally:
            if saved_token is not None:
                os.environ["WAQI_API_TOKEN"] = saved_token

    def test_waqi_map_uses_city_search_when_bounds_returns_no_stations(self):
        saved_token = os.environ.get("WAQI_API_TOKEN")
        os.environ["WAQI_API_TOKEN"] = "test-token"
        search_results = [
            {"uid": 13876, "aqi": "61", "time": {"stime": "2026-10-26 10:00:00"}, "station": {"name": "Sector-53, Chandigarh, India", "geo": ["30.719859", "76.738637"], "url": "india/chandigarh/sector-53"}},
            {"uid": 12428, "aqi": "117", "station": {"name": "Sector-25, Chandigarh, India", "geo": [30.751462, 76.762879], "url": "india/chandigarh/sector-25"}},
            {"uid": 13741, "aqi": "61", "station": {"name": "Sector 22, Chandigarh, India", "geo": [30.735567, 76.775714], "url": "india/chandigarh/sector-22"}},
            {"uid": 8680, "aqi": "-", "station": {"name": "Sector 6 Panchkula, Panchkula, India", "geo": [30.7057778, 76.8531805], "url": "india/panchkula/sector-6-panchkula"}},
        ]
        try:
            feed_results = [
                {"status": "ok", "data": {"aqi": 61, "time": {"s": "2026-10-26 10:00:00"}}},
                {"status": "ok", "data": {"aqi": 117, "time": {"s": "2026-10-26 10:00:00"}}},
                {"status": "ok", "data": {"aqi": 61, "time": {"s": "2026-10-26 10:00:00"}}},
            ]
            with patch.object(airpocalypse, "fetch_json", side_effect=[{"status": "ok", "data": []}, {"status": "ok", "data": search_results}, *feed_results]) as fetch:
                response = self.client.get("/api/map/waqi-stations?south=30.6&west=76.6&north=30.9&east=76.9")
            self.assertEqual(response.status_code, 200)
            data = response.get_json()
            self.assertTrue(data["search_fallback"])
            self.assertEqual([station["uid"] for station in data["stations"]], [13876, 12428, 13741])
            self.assertEqual(data["stations"][0]["latitude"], 30.719859)
            self.assertEqual(data["stations"][0]["longitude"], 76.738637)
            self.assertEqual(data["stations"][0]["aqi"], 61)
            self.assertEqual(data["stations"][0]["timestamp"], "2026-10-26 10:00:00")
            self.assertTrue(data["stations"][0]["station_url"].startswith("https://aqicn.org/"))
            self.assertEqual(fetch.call_count, 5)
        finally:
            if saved_token is None:
                os.environ.pop("WAQI_API_TOKEN", None)
            else:
                os.environ["WAQI_API_TOKEN"] = saved_token

    def test_source_candidates_are_not_claimed_as_connected(self):
        response = self.client.get("/sources")
        self.assertIn(b"NOT CONNECTED", response.data)
        self.assertIn(b"No external air-quality feed is connected", response.data)

    def test_simulator_exposes_working_screening_controls_and_limits(self):
        simulator = self.client.get("/simulator")
        self.assertIn(b"Restrict road motor vehicles", simulator.data)
        self.assertIn(b"100% RESTRICTION", simulator.data)
        self.assertIn(b"Restrict trucks &amp; heavy vehicles", simulator.data)
        self.assertIn(b"Firecracker emission controls", simulator.data)
        self.assertIn(b"Winter smog intensity", simulator.data)
        self.assertIn(b"QUICK PLAY", simulator.data)
        self.assertIn(b"Cleaner commute", simulator.data)
        self.assertIn(b"Dust-free build", simulator.data)
        self.assertIn(b"Winter haze", simulator.data)
        self.assertIn(b"Reset controls", simulator.data)
        self.assertIn(b"Construction dust controls", simulator.data)
        self.assertIn(b"Green infrastructure coverage", simulator.data)
        self.assertIn(b"ILLUSTRATIVE, NOT A FORECAST", simulator.data)
        self.assertIn(b"CITY AIR SNAPSHOT", simulator.data)
        self.assertIn(b"How your scenario feels", simulator.data)
        self.assertIn(b"air-quality-meter", simulator.data)
        self.assertIn(b"More insights", simulator.data)
        self.assertIn(b"Scenario", simulator.data)
        self.assertIn(b"Baseline", simulator.data)
        self.assertIn(b"INTELLIGENCE", simulator.data)
        self.assertIn("0 · BALANCED".encode(), simulator.data)
        self.assertIn("150 · MODERATE".encode(), simulator.data)
        self.assertIn("500 · POOR".encode(), simulator.data)
        self.assertIn(b"GRAP REFERENCE METER", simulator.data)
        self.assertIn(b"Level 1 201", simulator.data)
        self.assertIn(b"not active in Chandigarh", simulator.data)
        self.assertIn(b"Assumed annual AQI increase", simulator.data)
        self.assertIn(b"CURRENT-CONTROLS OUTLOOK", simulator.data)
        self.assertIn(b"current control settings remain in place", simulator.data)
        self.assertNotIn(b"CALCULATION ENGINE NOT BUILT", simulator.data)
        self.assertNotIn(b"Calculate illustrative range", simulator.data)

    def test_simulator_script_updates_stage_and_advice_with_scenario(self):
        simulator_script = (Path(airpocalypse.ROOT) / "static" / "js" / "simulator.js").read_text(encoding="utf-8")
        self.assertIn("const scenarioAqi = Math.round((scenarioAqiRange.low + scenarioAqiRange.high) / 2)", simulator_script)
        self.assertIn("setAirQuality(scenarioAqi)", simulator_script)
        self.assertIn("updateProjection(scenarioAqi)", simulator_script)
        self.assertIn("growthInput.addEventListener(\"input\", calculate)", simulator_script)
        self.assertIn('if (aqi <= 50) return { label: "Balanced", condition: "balanced" }', simulator_script)
        self.assertIn('if (aqi <= 150) return { label: "Moderate", condition: "moderate" }', simulator_script)
        self.assertIn('return { label: "Poor", condition: "poor" }', simulator_script)
        self.assertIn("updateAirScene(scenarioAqi, currentLevels, baselineAqi)", simulator_script)
        self.assertIn('getElementById("air-quality-baseline-marker")', simulator_script)
        self.assertIn('getElementById("air-quality-scenario-marker")', simulator_script)
        self.assertIn("recommendControls(pm25, pm10, aqiScale, currentLevels, scenarioAqiRange.high)", simulator_script)
        self.assertIn("requiredReduction = Math.max(0, scenarioHigh - targetAqi)", simulator_script)
        self.assertIn("all five emission controls at 100%", simulator_script)

    def test_simulator_grap_meter_and_current_controls_projection_are_dynamic(self):
        simulator_script = (Path(airpocalypse.ROOT) / "static" / "js" / "simulator.js").read_text(encoding="utf-8")
        self.assertIn("const grapLevel = (aqi)", simulator_script)
        self.assertIn("if (aqi <= 200) return \"Below Level 1\"", simulator_script)
        self.assertIn("if (aqi <= 450) return \"Level 3\"", simulator_script)
        self.assertIn("scenarioAqi * growthFactor", simulator_script)
        self.assertIn("for (let year = 1; year <= 5; year += 1)", simulator_script)
        self.assertIn("updateGrapMeter(scenarioAqi)", simulator_script)
        self.assertIn("Starting seasonal default for", simulator_script)
        self.assertIn("const winterDefault = seasonalWinterDefault(new Date().getMonth() + 1)", simulator_script)
        self.assertIn("winterIntensity * winterLow", simulator_script)
        self.assertIn("winterIntensity * winterHigh", simulator_script)
        self.assertIn('controls = ["traffic", "heavy", "dust", "crackers", "green"]', simulator_script)

    def test_simulator_updates_in_browser_without_a_json_calculation_request(self):
        simulator_script = (Path(airpocalypse.ROOT) / "static" / "js" / "simulator.js").read_text(encoding="utf-8")
        self.assertIn('input.addEventListener("input"', simulator_script)
        self.assertNotIn('fetch("/api/simulate"', simulator_script)
        self.assertNotIn("response.json()", simulator_script)

    def test_simulator_baseline_uses_open_meteo_chandigarh_aqi(self):
        simulator_script = (Path(airpocalypse.ROOT) / "static" / "js" / "simulator.js").read_text(encoding="utf-8")
        self.assertIn("const modelAqi = Number(estimate.aqi)", simulator_script)
        self.assertIn("modeledBaselineAqi = Number.isFinite(modelAqi)", simulator_script)
        self.assertIn("? modeledBaselineAqi", simulator_script)
        self.assertIn("baselineEdited", simulator_script)

    def test_scenario_api_calculates_restrictions_without_zeroing_aqi(self):
        baseline = {"pm25": 80, "pm10": 110, "traffic": 0, "dust": 0, "green": 0}
        no_controls = self.client.post("/api/simulate", json=baseline)
        self.assertEqual(no_controls.status_code, 200)
        no_control_result = no_controls.get_json()
        self.assertEqual(no_control_result["baseline"]["aqi"], no_control_result["scenario"]["aqi"]["scenario_low"])
        self.assertEqual(no_control_result["baseline"]["aqi"], no_control_result["scenario"]["aqi"]["scenario_high"])

        full_restriction = self.client.post("/api/simulate", json={**baseline, "traffic": 100})
        self.assertEqual(full_restriction.status_code, 200)
        result = full_restriction.get_json()
        self.assertLess(result["scenario"]["pm25"]["scenario_high"], baseline["pm25"])
        self.assertGreater(result["scenario"]["aqi"]["scenario_high"], 0)
        self.assertLessEqual(result["scenario"]["aqi"]["scenario_high"], result["baseline"]["aqi"])

    def test_dust_and_green_controls_change_the_scenario_range(self):
        baseline = {"pm25": 80, "pm10": 110, "traffic": 0, "dust": 0, "green": 0}
        no_controls = self.client.post("/api/simulate", json=baseline).get_json()
        dust_controls = self.client.post("/api/simulate", json={**baseline, "dust": 100}).get_json()
        green_controls = self.client.post("/api/simulate", json={**baseline, "green": 100}).get_json()
        self.assertLess(dust_controls["scenario"]["pm10"]["scenario_high"], no_controls["scenario"]["pm10"]["scenario_high"])
        self.assertLess(green_controls["scenario"]["pm25"]["scenario_low"], no_controls["scenario"]["pm25"]["scenario_low"])

    def test_scenario_api_rejects_out_of_range_inputs(self):
        response = self.client.post("/api/simulate", json={"pm25": 10, "pm10": 20, "traffic": 101, "dust": 0, "green": 0})
        self.assertEqual(response.status_code, 400)
        self.assertIn("between 0 and 100%", response.get_json()["error"])

    def test_comparison_page_remains_explicitly_inactive(self):
        comparison = self.client.get("/scenarios")
        self.assertIn(b"COMPARISON NOT ACTIVE", comparison.data)
        self.assertIn(b"NOT CALCULATED", comparison.data)

    def test_dashboard_accepts_only_supported_trend_windows(self):
        for window in ("24h", "7d", "30d", "90d", "invalid"):
            with self.subTest(window=window):
                response = self.client.get(f"/?window={window}")
                self.assertEqual(response.status_code, 200)
                if window in {"24h", "7d", "30d", "90d"}:
                    self.assertIn(b"MODELED HISTORY", response.data)

    def test_open_meteo_history_returns_daily_model_aqi(self):
        history = {
            "labels": ["28 Jul", "29 Jul"],
            "values": [32.5, None],
            "start_date": "2026-07-28",
            "end_date": "2026-07-29",
        }
        with patch.object(airpocalypse, "fetch_open_meteo_history", return_value=history) as fetch_history:
            response = self.client.get("/api/history/open-meteo?window=7d")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_json()["values"], [32.5, None])
        self.assertEqual(response.get_json()["source"], "Open-Meteo Air Quality API")
        self.assertIn("max-age=21600", response.headers["Cache-Control"])
        self.assertEqual(fetch_history.call_args.args[2], "7d")

    def test_open_meteo_daily_history_uses_median(self):
        payload = {
            "hourly": {
                "time": ["2026-01-01T00:00", "2026-01-01T01:00", "2026-01-01T02:00"],
                "us_aqi": [10, 20, 300],
            }
        }
        airpocalypse.fetch_open_meteo_history.cache_clear()
        with patch.object(airpocalypse, "fetch_json", return_value=payload):
            history = airpocalypse.fetch_open_meteo_history("2026-01-01", "2026-01-01", "7d")
        self.assertEqual(history["values"], [20.0])
        airpocalypse.fetch_open_meteo_history.cache_clear()

    def test_open_meteo_history_rejects_unknown_window(self):
        response = self.client.get("/api/history/open-meteo?window=365d")
        self.assertEqual(response.status_code, 400)

    def test_health_endpoint(self):
        response = self.client.get("/healthz")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_json()["status"], "ok")


if __name__ == "__main__":
    unittest.main()
