(() => {
  const form = document.getElementById("scenario-form");
  if (!form) return;

  const pm25Input = document.getElementById("baseline-pm25");
  const pm10Input = document.getElementById("baseline-pm10");
  const feedback = document.getElementById("scenario-feedback");
  const baselineStatus = document.getElementById("baseline-status");
  const sourceLabel = document.getElementById("scenario-source");
  const controls = ["traffic", "dust", "green"];
  const sourceShares = {
    pm25: { traffic: [0.08, 0.25], dust: [0.02, 0.12], green: [0, 0.03] },
    pm10: { traffic: [0.05, 0.2], dust: [0.15, 0.4], green: [0, 0.05] },
  };
  let baselineSource = "Open-Meteo modeled city estimate";
  let modeledBaselineAqi = null;
  let baselineEdited = false;

  const setText = (id, value) => {
    const element = document.getElementById(id);
    if (element) element.textContent = value;
  };
  const showError = (message) => {
    feedback.hidden = false;
    feedback.textContent = message;
  };
  const readNumber = (input) => {
    const value = Number(input.value);
    return input.value.trim() !== "" && Number.isFinite(value) ? value : null;
  };
  const format = (value) => Number(value).toFixed(1);
  const particulateAqi = (concentration, pollutant) => {
    const breakpoints = pollutant === "pm25"
      ? [[0, 9, 0, 50], [9.1, 35.4, 51, 100], [35.5, 55.4, 101, 150], [55.5, 125.4, 151, 200], [125.5, 225.4, 201, 300], [225.5, 325.4, 301, 500]]
      : [[0, 54, 0, 50], [55, 154, 51, 100], [155, 254, 101, 150], [255, 354, 151, 200], [355, 424, 201, 300], [425, 604, 301, 500]];
    const rounded = pollutant === "pm25" ? Math.floor(Math.max(0, concentration) * 10) / 10 : Math.floor(Math.max(0, concentration));
    const range = breakpoints.find(([low, high]) => rounded >= low && rounded <= high);
    if (!range) return 500;
    const [low, high, indexLow, indexHigh] = range;
    return Math.round((indexHigh - indexLow) / (high - low) * (rounded - low) + indexLow);
  };
  const getScenarioRange = (concentration, pollutant) => {
    const controlsTaken = Object.fromEntries(controls.map((name) => [name, Number(document.getElementById(name).value) / 100]));
    let remainingLow = 1;
    let remainingHigh = 1;
    for (const control of controls) {
      const [shareLow, shareHigh] = sourceShares[pollutant][control];
      remainingLow *= 1 - controlsTaken[control] * shareLow;
      remainingHigh *= 1 - controlsTaken[control] * shareHigh;
    }
    const reductionLow = Math.min(0.85, 1 - remainingLow);
    const reductionHigh = Math.min(0.85, 1 - remainingHigh);
    return {
      low: concentration * (1 - reductionHigh),
      high: concentration * (1 - reductionLow),
      reductionLow,
      reductionHigh,
    };
  };
  const calculate = () => {
    const pm25 = readNumber(pm25Input);
    const pm10 = readNumber(pm10Input);
    if (pm25 === null || pm10 === null) {
      setText("baseline-aqi", "—");
      setText("scenario-aqi", "—");
      setText("scenario-pm25", "—");
      setText("scenario-pm10", "—");
      setText("baseline-pm25-result", "Baseline — µg/m³");
      setText("baseline-pm10-result", "Baseline — µg/m³");
      showError("Enter PM₂.₅ and PM₁₀ values between 0 and 1000 µg/m³.");
      return;
    }
    if (pm25 < 0 || pm25 > 1000 || pm10 < 0 || pm10 > 1000) {
      showError("Baseline particulate values must be between 0 and 1000 µg/m³.");
      return;
    }

    feedback.hidden = true;
    const pm25Range = getScenarioRange(pm25, "pm25");
    const pm10Range = getScenarioRange(pm10, "pm10");
    const particulateBaselineAqi = Math.max(particulateAqi(pm25, "pm25"), particulateAqi(pm10, "pm10"));
    const baselineAqi = !baselineEdited && modeledBaselineAqi !== null
      ? modeledBaselineAqi
      : particulateBaselineAqi;
    const particulateScenarioLow = Math.max(
      particulateAqi(pm25Range.low, "pm25"),
      particulateAqi(pm10Range.low, "pm10"),
    );
    const particulateScenarioHigh = Math.max(
      particulateAqi(pm25Range.high, "pm25"),
      particulateAqi(pm10Range.high, "pm10"),
    );
    const aqiScale = particulateBaselineAqi > 0 ? baselineAqi / particulateBaselineAqi : 1;
    const scenarioAqiLow = Math.min(
      Math.round(particulateScenarioLow * aqiScale),
      Math.round(particulateScenarioHigh * aqiScale),
    );
    const scenarioAqiHigh = Math.min(500, Math.max(
      Math.round(particulateScenarioLow * aqiScale),
      Math.round(particulateScenarioHigh * aqiScale),
    ));
    setText("baseline-aqi", String(baselineAqi));
    setText("scenario-aqi", `${scenarioAqiLow}–${scenarioAqiHigh}`);
    setText("scenario-pm25", `${format(pm25Range.low)}–${format(pm25Range.high)}`);
    setText("scenario-pm10", `${format(pm10Range.low)}–${format(pm10Range.high)}`);
    setText("baseline-pm25-result", `Baseline ${format(pm25)} µg/m³`);
    setText("baseline-pm10-result", `Baseline ${format(pm10)} µg/m³`);
    const minimumReduction = Math.min(pm25Range.reductionLow, pm10Range.reductionLow) * 100;
    const maximumReduction = Math.max(pm25Range.reductionHigh, pm10Range.reductionHigh) * 100;
    setText("scenario-impact", `Illustrative reduction: ${format(minimumReduction)}–${format(maximumReduction)}% particulate`);
    sourceLabel.textContent = `Baseline source: ${baselineEdited ? "manual values" : baselineSource}. Scenario output is illustrative, not a forecast.`;
  };

  controls.forEach((name) => {
    const input = document.getElementById(name);
    const output = document.getElementById(`${name}-value`);
    input.addEventListener("input", () => {
      output.value = `${input.value}%`;
      output.textContent = `${input.value}%`;
      calculate();
    });
  });

  [pm25Input, pm10Input].forEach((input) => {
    input.addEventListener("input", () => {
      baselineEdited = true;
      baselineStatus.textContent = "Using your manually entered baseline values.";
      sourceLabel.textContent = "Baseline source: manually entered particulate values.";
      calculate();
    });
  });

  form.addEventListener("submit", (event) => event.preventDefault());

  const loadBaseline = async () => {
    try {
      const estimate = await window.fetchOpenMeteoEstimate();
      if (estimate.pm25 == null || estimate.pm10 == null || !Number.isFinite(Number(estimate.pm25)) || !Number.isFinite(Number(estimate.pm10))) {
        throw Error("Open-Meteo did not return numeric PM₂.₅ and PM₁₀ values.");
      }
      if (!baselineEdited) {
        const modelAqi = Number(estimate.aqi);
        modeledBaselineAqi = Number.isFinite(modelAqi) && modelAqi >= 0 ? Math.round(modelAqi) : null;
        pm25Input.value = estimate.pm25;
        pm10Input.value = estimate.pm10;
        baselineSource = `Open-Meteo modeled city estimate${estimate.timestamp ? ` (${estimate.timestamp})` : ""}`;
        baselineStatus.textContent = `Loaded current Open-Meteo modeled particulate and AQI values${estimate.timestamp ? ` for ${estimate.timestamp}` : ""}. The baseline AQI matches the Chandigarh model reading.`;
        sourceLabel.textContent = `Baseline source: ${baselineSource}.`;
        calculate();
      }
    } catch (error) {
      baselineStatus.textContent = `Could not load Open-Meteo baseline: ${error.message || "provider unavailable"}. Enter PM₂.₅ and PM₁₀ values manually to continue.`;
    }
  };

  loadBaseline();
})();
