window.fetchOpenMeteoEstimate = async () => {
  const response = await fetch("https://air-quality-api.open-meteo.com/v1/air-quality?latitude=30.7333&longitude=76.7794&current=us_aqi,pm2_5,pm10&timezone=Asia%2FKolkata", { signal: AbortSignal.timeout(10000) });
  const body = await response.text();
  let data;
  try {
    data = JSON.parse(body);
  } catch {
    throw Error(`Open-Meteo returned a non-JSON response (HTTP ${response.status}).`);
  }
  if (!response.ok || !data.current) throw Error("Open-Meteo did not provide a current model estimate.");
  return {
    latitude: data.latitude,
    longitude: data.longitude,
    timestamp: data.current.time,
    aqi: data.current.us_aqi,
    pm25: data.current.pm2_5,
    pm10: data.current.pm10,
  };
};