(() => {
  const sourceSelect = document.getElementById("overview-source");
  const metrics = document.querySelector(".metric-grid");
  const tokenNode = document.getElementById("waqi-browser-token");
  let browserWaqiToken = null;
  try { browserWaqiToken = tokenNode ? JSON.parse(tokenNode.textContent || "null") : null; } catch { /* server proxy remains available */ }
  const setText = (id, value) => {
    const element = document.getElementById(id);
    if (element) element.textContent = value;
  };
  const setPageLoading = (isLoading) => {
    const page = document.querySelector(".page-container");
    if (!page) return;
    page.classList.toggle("is-data-loading", isLoading);
    page.setAttribute("aria-busy", String(isLoading));
  };
  const setState = (id, value) => {
    const element = document.getElementById(id);
    if (element?.lastChild) element.lastChild.textContent = ` ${value}`;
  };
  const numeric = (value) => value !== null && value !== undefined && value !== "" && Number.isFinite(Number(value)) ? Number(value) : null;
  const median = (readings) => {
    const values = readings.filter((value) => value !== null).sort((left, right) => left - right);
    if (!values.length) return null;
    const middle = Math.floor(values.length / 2);
    return values.length % 2 ? values[middle] : (values[middle - 1] + values[middle]) / 2;
  };
  const stationMedian = (stations, key) => {
    return median(stations.map((station) => numeric(station[key])).filter((value) => value !== null));
  };
  const snapshot = metrics ? Object.fromEntries(["aqi", "pm25", "pm10"].map((key) => [key, {
    value: document.getElementById(`overview-${key}`)?.textContent || "—",
    state: document.getElementById(`overview-${key}-state`)?.lastChild?.textContent || " No reading available",
  }])) : null;
  const initialBanner = {
    status: document.getElementById("overview-source-status")?.textContent || "",
    title: document.getElementById("overview-data-title")?.textContent || "",
    description: document.getElementById("overview-data-description")?.textContent || "",
  };

  const showValues = ({ aqi, pm25, pm10 }, label, status, description) => {
    setText("overview-aqi", aqi == null ? "—" : String(Math.round(aqi)));
    setText("overview-pm25", pm25 == null ? "—" : pm25.toFixed(1));
    setText("overview-pm10", pm10 == null ? "—" : pm10.toFixed(1));
    setState("overview-aqi-state", label);
    setState("overview-pm25-state", label);
    setState("overview-pm10-state", label);
    setText("overview-aqi-standard", "US EPA AQI");
    setText("overview-source-status", status);
    setText("overview-data-title", `${status.toLowerCase()} loaded`);
    setText("overview-data-description", description);
  };

  const browserWaqiStations = async () => {
    if (!browserWaqiToken) throw Error("WAQI is unavailable: configure WAQI_API_TOKEN for the browser fallback.");
    const searchQuery = new URLSearchParams({ keyword: "Chandigarh", token: browserWaqiToken });
    const searchResponse = await fetch(`https://api.waqi.info/search/?${searchQuery}`, { signal: AbortSignal.timeout(12000) });
    const searchPayload = await searchResponse.json();
    if (!searchResponse.ok || searchPayload.status !== "ok" || !Array.isArray(searchPayload.data)) throw Error("WAQI could not return Chandigarh stations.");
    return Promise.all(searchPayload.data.flatMap((item) => {
      const station = item.station || {};
      const name = station.name || "";
      if (!name.toLowerCase().includes("chandigarh") || !Number.isFinite(Number(item.uid))) return [];
      return [{ uid: item.uid, aqi: item.aqi, pm25: null, pm10: null }];
    }).map(async (station) => {
      try {
        const query = new URLSearchParams({ token: browserWaqiToken });
        const response = await fetch(`https://api.waqi.info/feed/@${station.uid}/?${query}`, { signal: AbortSignal.timeout(10000) });
        const payload = await response.json();
        if (!response.ok || payload.status !== "ok" || !payload.data) return station;
        const measurements = payload.data.iaqi || {};
        return {
          aqi: payload.data.aqi ?? station.aqi,
          pm25: measurements.pm25?.v,
          pm10: measurements.pm10?.v,
        };
      } catch {
        return station;
      }
    }));
  };

  const loadWaqi = async () => {
    const params = new URLSearchParams({ south: "30.6", west: "76.6", north: "30.9", east: "76.9" });
    try {
      const response = await fetch(`/api/map/waqi-stations?${params}`, { signal: AbortSignal.timeout(15000) });
      const payload = await response.json();
      if (response.ok && payload.stations?.length) return payload.stations.filter((station) => station.name?.toLowerCase().includes("chandigarh"));
    } catch { /* browser fallback below */ }
    return browserWaqiStations();
  };

  const loadSource = async (source) => {
    if (!metrics || !sourceSelect) return;
    if (source === "measured") {
      for (const key of ["aqi", "pm25", "pm10"]) {
        setText(`overview-${key}`, snapshot[key].value);
        setState(`overview-${key}-state`, snapshot[key].state.trim());
      }
      setText("overview-aqi-standard", "INDIA AQI");
      setText("overview-source-status", initialBanner.status);
      setText("overview-data-title", initialBanner.title);
      setText("overview-data-description", initialBanner.description);
      return;
    }

    setText("overview-source-status", `${source.toUpperCase()} LOADING`);
    setText("overview-data-description", "Fetching the selected current air-quality source.");
    setPageLoading(true);
    sourceSelect.disabled = true;
    try {
      if (source === "open-meteo") {
        const estimate = await window.fetchOpenMeteoEstimate();
        showValues({ aqi: numeric(estimate.aqi), pm25: numeric(estimate.pm25), pm10: numeric(estimate.pm10) }, "Open-Meteo estimate", "OPEN-METEO MODEL ESTIMATE", "Current city-level model estimate. AQI follows the US EPA scale; values are not station measurements.");
      } else {
        const stations = await loadWaqi();
        const readings = {
          aqi: stationMedian(stations, "aqi"),
          pm25: stationMedian(stations, "pm25"),
          pm10: stationMedian(stations, "pm10"),
        };
        const count = stations.filter((station) => numeric(station.aqi) !== null).length;
        const label = `WAQI median (${count} station${count === 1 ? "" : "s"})`;
        if (readings.aqi == null) throw Error("WAQI returned no numeric AQI readings for Chandigarh stations.");
        showValues(readings, label, "WAQI STATION MEDIAN", `Median of available readings from ${count} Chandigarh WAQI stations. This is less sensitive to station outliers; AQI uses the US EPA scale and PM values are summarized independently.`);
      }
    } catch (error) {
      setText("overview-source-status", `${source.toUpperCase()} UNAVAILABLE`);
      setText("overview-data-title", "Selected source unavailable");
      setText("overview-data-description", error.message || "Could not load the selected air-quality source.");
    } finally {
      sourceSelect.disabled = false;
      setPageLoading(false);
    }
  };

  if (sourceSelect) {
    sourceSelect.addEventListener("change", () => loadSource(sourceSelect.value));
    if (sourceSelect.value !== "measured") loadSource(sourceSelect.value);
  }

  const dataNode = document.getElementById("trend-data");
  const canvas = document.getElementById("aqi-chart");
  if (!dataNode || !canvas) return;

  let trend;
  try {
    trend = JSON.parse(dataNode.textContent || "{}");
  } catch {
    return;
  }

  let trendChart = null;
  const indiaDate = (date) => {
    const parts = new Intl.DateTimeFormat("en", {
      timeZone: "Asia/Kolkata",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
    }).formatToParts(date);
    const values = Object.fromEntries(parts.map(({ type, value }) => [type, value]));
    return `${values.year}-${values.month}-${values.day}`;
  };
  const shiftDate = (dateString, days) => {
    const date = new Date(`${dateString}T00:00:00Z`);
    date.setUTCDate(date.getUTCDate() + days);
    return date.toISOString().slice(0, 10);
  };
  const fetchBrowserHistory = async () => {
    const today = indiaDate(new Date());
    const days = { "24h": 1, "7d": 7, "30d": 30, "90d": 90 }[trend.window] || 90;
    const endDate = shiftDate(today, -1);
    const startDate = shiftDate(endDate, -(days - 1));
    const params = new URLSearchParams({
      latitude: "30.7333",
      longitude: "76.7794",
      hourly: "us_aqi",
      start_date: startDate,
      end_date: endDate,
      timezone: "Asia/Kolkata",
    });
    const response = await fetch(`https://air-quality-api.open-meteo.com/v1/air-quality?${params}`, {
      signal: AbortSignal.timeout(25000),
    });
    const payload = await response.json();
    if (!response.ok || !Array.isArray(payload.hourly?.time) || !Array.isArray(payload.hourly?.us_aqi)) {
      throw Error(payload.reason || "Open-Meteo returned no hourly AQI history.");
    }

    if (trend.window === "24h") {
      const points = payload.hourly.time.map((timestamp, index) => ({
        timestamp,
        value: numeric(payload.hourly.us_aqi[index]),
      })).slice(-24);
      return {
        labels: points.map(({ timestamp }) => new Date(`${timestamp}:00+05:30`).toLocaleTimeString("en", {
          hour: "numeric",
          timeZone: "Asia/Kolkata",
        })),
        values: points.map(({ value }) => value),
      };
    }

    const dailyValues = new Map();
    payload.hourly.time.forEach((timestamp, index) => {
      const value = numeric(payload.hourly.us_aqi[index]);
      if (value === null) return;
      const values = dailyValues.get(timestamp.slice(0, 10)) || [];
      values.push(value);
      dailyValues.set(timestamp.slice(0, 10), values);
    });

    const labels = [];
    const values = [];
    for (let day = startDate; day <= endDate; day = shiftDate(day, 1)) {
      labels.push(new Date(`${day}T12:00:00Z`).toLocaleDateString("en", { day: "2-digit", month: "short", timeZone: "UTC" }));
      const readings = dailyValues.get(day) || [];
      values.push(readings.length ? median(readings) : null);
    }
    return { labels, values };
  };

  const loadHistoricalTrend = async () => {
    const emptyState = document.getElementById("chart-empty");
    try {
      let payload;
      try {
        payload = await fetchBrowserHistory();
      } catch {
        const response = await fetch(`/api/history/open-meteo?window=${encodeURIComponent(trend.window)}`, { signal: AbortSignal.timeout(20000) });
        const serverPayload = await response.json();
        if (!response.ok) throw Error(serverPayload.error || "Open-Meteo history is unavailable.");
        payload = serverPayload;
      }
      if (!Array.isArray(payload.labels) || !Array.isArray(payload.values) || payload.labels.length !== payload.values.length) {
        throw Error("Open-Meteo returned an invalid history series.");
      }
      trendChart.data.labels = payload.labels;
      trendChart.data.datasets[0].data = payload.values;
      trendChart.update();
      emptyState?.classList.add("is-hidden");
    } catch (error) {
      setText("chart-empty-title", "Historical model data unavailable");
      setText("chart-empty-description", error.message || "Could not load Open-Meteo history.");
      emptyState?.classList.remove("is-hidden");
    }
  };

  const draw = () => {
    if (!window.Chart || canvas.dataset.chartReady) return;
    canvas.dataset.chartReady = "true";
    const context = canvas.getContext("2d");
    const gradient = context.createLinearGradient(0, 0, 0, 210);
    gradient.addColorStop(0, "rgba(126, 219, 136, 0.2)");
    gradient.addColorStop(1, "rgba(126, 219, 136, 0)");

    const modeledHistory = trend.modeled;
    trendChart = new Chart(context, {
      type: "line",
      data: {
        labels: trend.labels || [],
        datasets: [{
          label: modeledHistory ? "Open-Meteo modeled AQI" : "Measured AQI",
          data: trend.values || [],
          borderColor: "#8fdb91",
          backgroundColor: gradient,
          borderWidth: 2,
          pointRadius: (context) => context.raw === null ? 0 : 3,
          pointHoverRadius: 5,
          pointBackgroundColor: "#a7e8a2",
          pointBorderColor: "#122018",
          pointBorderWidth: 2,
          fill: true,
          tension: 0.35,
          spanGaps: false,
        }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        animation: { duration: 500 },
        interaction: { intersect: false, mode: "index" },
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: "#18231c",
            borderColor: "#38513d",
            borderWidth: 1,
            titleColor: "#9bab9e",
            bodyColor: "#e4eee5",
            padding: 10,
            callbacks: {
              label: (item) => {
                if (item.raw == null) return modeledHistory ? "No model estimate" : "No measured reading";
                if (!modeledHistory) return `Measured median AQI: ${item.raw}`;
                return trend.window === "24h" ? `Modeled AQI: ${item.raw}` : `Modeled median AQI: ${item.raw}`;
              },
            },
          },
        },
        scales: {
          x: {
            grid: { display: false },
            border: { color: "#2b3930" },
            ticks: { color: "#7c8a80", maxTicksLimit: 8, font: { family: "DM Mono", size: 8 } },
          },
          y: {
            beginAtZero: true,
            suggestedMax: 100,
            grid: { color: "rgba(119, 143, 124, 0.12)" },
            border: { display: false },
            ticks: { color: "#718076", maxTicksLimit: 5, font: { family: "DM Mono", size: 8 } },
          },
        },
      },
    });
  };

  if (window.Chart) {
    draw();
    if (trend.modeled) loadHistoricalTrend();
  } else {
    const chartScript = document.querySelector('script[src*="chart.umd.min.js"]');
    if (chartScript) chartScript.addEventListener("load", () => {
      draw();
      if (trend.modeled) loadHistoricalTrend();
    }, { once: true });
  }
})();
