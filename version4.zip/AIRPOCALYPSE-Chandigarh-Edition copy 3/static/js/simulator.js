(() => {
  const form = document.getElementById("scenario-form");
  if (!form) return;

  const pm25Input = document.getElementById("baseline-pm25");
  const pm10Input = document.getElementById("baseline-pm10");
  const growthInput = document.getElementById("annual-growth");
  const feedback = document.getElementById("scenario-feedback");
  const baselineStatus = document.getElementById("baseline-status");
  const sourceLabel = document.getElementById("scenario-source");
  const controls = ["traffic", "heavy", "dust", "crackers", "green"];
  const sliders = [...controls, "winter"];
  const sourceShares = {
    pm25: { traffic: [0.08, 0.25], heavy: [0.04, 0.15], dust: [0.02, 0.12], crackers: [0.01, 0.12], green: [0, 0.03] },
    pm10: { traffic: [0.05, 0.2], heavy: [0.05, 0.2], dust: [0.15, 0.4], crackers: [0.01, 0.08], green: [0, 0.05] },
  };
  const winterShares = { pm25: [0.08, 0.25], pm10: [0.05, 0.18] };
  let baselineSource = "Open-Meteo modeled city estimate";
  let modeledBaselineAqi = null;
  let baselineEdited = false;

  const setText = (id, value) => {
    const element = document.getElementById(id);
    if (element) element.textContent = value;
  };
  const seasonalWinterDefault = (month) => ({
    1: 100,
    2: 75,
    3: 35,
    10: 25,
    11: 60,
    12: 100,
  })[month] ?? 0;
  const winterDefault = seasonalWinterDefault(new Date().getMonth() + 1);
  const winterInput = document.getElementById("winter");
  const winterOutput = document.getElementById("winter-value");
  const monthName = new Intl.DateTimeFormat("en", { month: "long" }).format(new Date());
  winterInput.value = String(winterDefault);
  winterOutput.value = `${winterDefault}%`;
  winterOutput.textContent = `${winterDefault}%`;
  setText("winter-season-default", `Starting seasonal default for ${monthName}: ${winterDefault}% of assumed peak winter smog. Adjust as needed.`);
  const airQuality = (aqi) => {
    if (aqi <= 50) return { label: "Balanced", condition: "balanced" };
    if (aqi <= 150) return { label: "Moderate", condition: "moderate" };
    return { label: "Poor", condition: "poor" };
  };
  const updateAirScene = (low, high, levels, baselineAqi) => {
    const scene = document.getElementById("air-scene");
    const graphic = document.getElementById("air-scene-graphic");
    const meter = document.getElementById("air-quality-meter");
    const status = airQuality(high);
    const averageTrafficControls = (levels.traffic + levels.heavy) / 2;
    scene.dataset.condition = status.condition;
    setText("air-scene-status", `${status.label} air`);
    meter.setAttribute("aria-valuenow", String(Math.min(500, high)));
    meter.setAttribute("aria-valuetext", `Scenario AQI ${low} to ${high}; ${status.label}`);
    document.getElementById("air-quality-baseline-marker").style.left = `${Math.min(100, baselineAqi / 500 * 100)}%`;
    document.getElementById("air-quality-scenario-marker").style.left = `${Math.min(100, high / 500 * 100)}%`;
    graphic.style.setProperty("--smog-opacity", String(0.12 + Math.min(high, 500) / 500 * 0.72));
    graphic.style.setProperty("--traffic-opacity", String(Math.max(0.12, 1 - averageTrafficControls / 100 * 0.88)));
    graphic.style.setProperty("--green-opacity", String(0.2 + levels.green / 100 * 0.8));
  };
  const setAirQuality = (low, high) => {
    const lowQuality = airQuality(low);
    const highQuality = airQuality(high);
    document.getElementById("air-scene").dataset.condition = highQuality.condition;
    setText("scenario-stage", lowQuality.condition === highQuality.condition
      ? highQuality.label
      : `${lowQuality.label}–${highQuality.label}`);
    setText("scenario-stage-detail", `Estimated scenario AQI ${low}–${high} · conservative label: ${highQuality.label}.`);
  };
  const grapLevel = (aqi) => {
    if (aqi <= 200) return "Below Level 1";
    if (aqi <= 300) return "Level 1";
    if (aqi <= 400) return "Level 2";
    if (aqi <= 450) return "Level 3";
    return "Level 4";
  };
  const updateGrapMeter = (low, high) => {
    const meter = document.getElementById("grap-meter");
    const marker = document.getElementById("grap-meter-marker");
    const conservativeLevel = grapLevel(high);
    meter.setAttribute("aria-valuenow", String(Math.min(500, high)));
    meter.setAttribute("aria-valuetext", `Scenario AQI ${low} to ${high}; ${conservativeLevel}, hypothetical reference only`);
    marker.style.left = `${Math.min(100, (high / 500) * 100)}%`;
    setText("grap-meter-label", low === high
      ? `${conservativeLevel} · AQI ${high}`
      : `${grapLevel(low)}–${conservativeLevel} · AQI ${low}–${high}`);
  };
  const updateProjection = (baselineAqi) => {
    const annualGrowth = readNumber(growthInput);
    const list = document.getElementById("projection-years");
    list.replaceChildren();
    if (!Number.isFinite(baselineAqi)) {
      setText("projection-disclaimer", "Enter valid baseline readings to calculate the illustrative no-new-controls scenario.");
      return;
    }
    if (annualGrowth === null || annualGrowth < 0 || annualGrowth > 25) {
      setText("projection-disclaimer", "Enter an annual AQI increase between 0% and 25% to calculate this illustrative no-new-controls scenario.");
      return;
    }
    setText("projection-disclaimer", `Illustrative scenario, not a forecast: baseline AQI ${baselineAqi}, with ${format(annualGrowth)}% assumed annual increase compounded; no interventions are applied.`);
    for (let year = 1; year <= 5; year += 1) {
      const projectedAqi = Math.round(baselineAqi * ((1 + annualGrowth / 100) ** year));
      const item = document.createElement("li");
      item.className = "projection-year";
      const label = document.createElement("span");
      label.textContent = `Year ${year}`;
      const bar = document.createElement("span");
      bar.className = "projection-bar";
      bar.setAttribute("aria-hidden", "true");
      const fill = document.createElement("span");
      fill.className = "projection-bar-fill";
      fill.style.width = `${Math.min(100, (projectedAqi / 500) * 100)}%`;
      bar.append(fill);
      const result = document.createElement("strong");
      result.textContent = `${projectedAqi} · ${grapLevel(projectedAqi)}`;
      item.append(label, bar, result);
      list.append(item);
    }
  };
  const setUnavailable = () => {
    const scene = document.getElementById("air-scene");
    scene.dataset.condition = "unknown";
    setText("baseline-aqi", "—");
    setText("scenario-aqi", "—");
    setText("scenario-pm25", "—");
    setText("scenario-pm10", "—");
    setText("scenario-impact", "Enter valid baseline readings to preview the scenario.");
    setText("scenario-stage", "—");
    setText("scenario-stage-detail", "Enter valid baseline readings to calculate the air-quality label.");
    setText("air-scene-status", "Waiting…");
    document.getElementById("air-scene-graphic").style.setProperty("--smog-opacity", "0.5");
    document.getElementById("air-scene-graphic").style.setProperty("--traffic-opacity", "1");
    document.getElementById("air-scene-graphic").style.setProperty("--green-opacity", "0.6");
    const meter = document.getElementById("air-quality-meter");
    meter.setAttribute("aria-valuenow", "0");
    meter.setAttribute("aria-valuetext", "Enter valid baseline readings");
    document.getElementById("air-quality-baseline-marker").style.left = "0%";
    document.getElementById("air-quality-scenario-marker").style.left = "0%";
    setText("scenario-advice-text", "Enter valid baseline readings to see the estimated reduction and recommended controls.");
    setText("grap-meter-label", "—");
    document.getElementById("grap-meter").setAttribute("aria-valuenow", "0");
    document.getElementById("grap-meter").setAttribute("aria-valuetext", "Enter valid baseline readings");
    document.getElementById("grap-meter-marker").style.left = "0%";
    document.getElementById("projection-years").replaceChildren();
    setText("projection-disclaimer", "Enter valid baseline readings to calculate the illustrative no-new-controls scenario.");
  };
  const showError = (message) => {
    feedback.hidden = false;
    feedback.textContent = message;
  };
  const readNumber = (input) => {
    const value = Number(input.value);
    return input.value.trim() !== "" && Number.isFinite(value) ? value : null;
  };
  const format = (value) => Number(value).toFixed(1);
  const particulateAqi = (concentration, pollutant) => {
    const breakpoints = pollutant === "pm25"
      ? [[0, 9, 0, 50], [9.1, 35.4, 51, 100], [35.5, 55.4, 101, 150], [55.5, 125.4, 151, 200], [125.5, 225.4, 201, 300], [225.5, 325.4, 301, 500]]
      : [[0, 54, 0, 50], [55, 154, 51, 100], [155, 254, 101, 150], [255, 354, 151, 200], [355, 424, 201, 300], [425, 604, 301, 500]];
    const rounded = pollutant === "pm25" ? Math.floor(Math.max(0, concentration) * 10) / 10 : Math.floor(Math.max(0, concentration));
    const range = breakpoints.find(([low, high]) => rounded >= low && rounded <= high);
    if (!range) return 500;
    const [low, high, indexLow, indexHigh] = range;
    return Math.round((indexHigh - indexLow) / (high - low) * (rounded - low) + indexLow);
  };
  const getScenarioRange = (concentration, pollutant, levels = null) => {
    const controlsTaken = Object.fromEntries(controls.map((name) => [
      name,
      (levels ? levels[name] : Number(document.getElementById(name).value)) / 100,
    ]));
    let remainingLow = 1;
    let remainingHigh = 1;
    for (const control of controls) {
      const [shareLow, shareHigh] = sourceShares[pollutant][control];
      remainingLow *= 1 - controlsTaken[control] * shareLow;
      remainingHigh *= 1 - controlsTaken[control] * shareHigh;
    }
    const reductionLow = Math.min(0.85, 1 - remainingLow);
    const reductionHigh = Math.min(0.85, 1 - remainingHigh);
    const winterIntensity = (levels ? levels.winter : Number(winterInput.value)) / 100;
    const [winterLow, winterHigh] = winterShares[pollutant];
    return {
      low: concentration * (1 + winterIntensity * winterLow) * (1 - reductionHigh),
      high: concentration * (1 + winterIntensity * winterHigh) * (1 - reductionLow),
      reductionLow,
      reductionHigh,
    };
  };
  const getScenarioAqiRange = (pm25, pm10, aqiScale, levels) => {
    const pm25Range = getScenarioRange(pm25, "pm25", levels);
    const pm10Range = getScenarioRange(pm10, "pm10", levels);
    const particulateLow = Math.max(
      particulateAqi(pm25Range.low, "pm25"),
      particulateAqi(pm10Range.low, "pm10"),
    );
    const particulateHigh = Math.max(
      particulateAqi(pm25Range.high, "pm25"),
      particulateAqi(pm10Range.high, "pm10"),
    );
    return {
      low: Math.min(Math.round(particulateLow * aqiScale), Math.round(particulateHigh * aqiScale)),
      high: Math.min(500, Math.max(Math.round(particulateLow * aqiScale), Math.round(particulateHigh * aqiScale))),
    };
  };
  const recommendControls = (pm25, pm10, aqiScale, currentLevels, scenarioHigh) => {
    const targetAqi = 50;
    const requiredReduction = Math.max(0, scenarioHigh - targetAqi);
    if (requiredReduction === 0) {
      return "The conservative scenario estimate is already in the Balanced range (AQI ≤50). Maintain the selected controls.";
    }

    const atMaximum = Object.fromEntries([
      ...controls.map((name) => [name, 100]),
      ["winter", currentLevels.winter],
    ]);
    if (getScenarioAqiRange(pm25, pm10, aqiScale, atMaximum).high > targetAqi) {
      const maximumEstimate = getScenarioAqiRange(pm25, pm10, aqiScale, atMaximum).high;
      return `The conservative estimate needs to fall by about ${requiredReduction} AQI points to reach Balanced air (AQI ≤50). Even with all five emission controls at 100%, this screening model estimates AQI ${maximumEstimate}; these controls alone may not be enough.`;
    }

    let low = 0;
    let high = 1;
    for (let iteration = 0; iteration < 20; iteration += 1) {
      const factor = (low + high) / 2;
      const levels = Object.fromEntries(controls.map((name) => [
        name,
        currentLevels[name] + (100 - currentLevels[name]) * factor,
      ]));
      levels.winter = currentLevels.winter;
      if (getScenarioAqiRange(pm25, pm10, aqiScale, levels).high <= targetAqi) high = factor;
      else low = factor;
    }

    const recommended = Object.fromEntries(controls.map((name) => [
      name,
      Math.ceil(currentLevels[name] + (100 - currentLevels[name]) * high),
    ]));
    return `The conservative scenario estimate needs to fall by about ${requiredReduction} AQI points to reach Balanced air (AQI ≤50). Try traffic ${recommended.traffic}%, heavy vehicles ${recommended.heavy}%, dust ${recommended.dust}%, crackers ${recommended.crackers}%, and greenery ${recommended.green}% or higher. These are model-based estimates, not guaranteed outcomes.`;
  };
  const calculate = () => {
    const pm25 = readNumber(pm25Input);
    const pm10 = readNumber(pm10Input);
    if (pm25 === null || pm10 === null) {
      setText("baseline-aqi", "—");
      setText("scenario-aqi", "—");
      setText("scenario-pm25", "—");
      setText("scenario-pm10", "—");
      setText("baseline-pm25-result", "Baseline — µg/m³");
      setText("baseline-pm10-result", "Baseline — µg/m³");
      setUnavailable();
      showError("Enter PM₂.₅ and PM₁₀ values between 0 and 1000 µg/m³.");
      return;
    }
    if (pm25 < 0 || pm25 > 1000 || pm10 < 0 || pm10 > 1000) {
      setUnavailable();
      showError("Baseline particulate values must be between 0 and 1000 µg/m³.");
      return;
    }

    feedback.hidden = true;
    const particulateBaselineAqi = Math.max(particulateAqi(pm25, "pm25"), particulateAqi(pm10, "pm10"));
    const baselineAqi = !baselineEdited && modeledBaselineAqi !== null
      ? modeledBaselineAqi
      : particulateBaselineAqi;
    const aqiScale = particulateBaselineAqi > 0 ? baselineAqi / particulateBaselineAqi : 1;
    const currentLevels = Object.fromEntries(controls.map((name) => [
      name,
      Number(document.getElementById(name).value),
    ]));
    currentLevels.winter = Number(winterInput.value);
    const pm25Range = getScenarioRange(pm25, "pm25", currentLevels);
    const pm10Range = getScenarioRange(pm10, "pm10", currentLevels);
    const { low: scenarioAqiLow, high: scenarioAqiHigh } = getScenarioAqiRange(pm25, pm10, aqiScale, currentLevels);
    setText("baseline-aqi", String(baselineAqi));
    setText("scenario-aqi", `${scenarioAqiLow}–${scenarioAqiHigh}`);
    setAirQuality(scenarioAqiLow, scenarioAqiHigh);
    updateAirScene(scenarioAqiLow, scenarioAqiHigh, currentLevels, baselineAqi);
    updateGrapMeter(scenarioAqiLow, scenarioAqiHigh);
    setText("scenario-advice-text", recommendControls(pm25, pm10, aqiScale, currentLevels, scenarioAqiHigh));
    updateProjection(baselineAqi);
    setText("scenario-pm25", `${format(pm25Range.low)}–${format(pm25Range.high)}`);
    setText("scenario-pm10", `${format(pm10Range.low)}–${format(pm10Range.high)}`);
    setText("baseline-pm25-result", `Baseline ${format(pm25)} µg/m³`);
    setText("baseline-pm10-result", `Baseline ${format(pm10)} µg/m³`);
    const reductionLow = Math.min(
      pm25 > 0 ? 1 - pm25Range.high / pm25 : 0,
      pm10 > 0 ? 1 - pm10Range.high / pm10 : 0,
    ) * 100;
    const reductionHigh = Math.max(
      pm25 > 0 ? 1 - pm25Range.low / pm25 : 0,
      pm10 > 0 ? 1 - pm10Range.low / pm10 : 0,
    ) * 100;
    const impact = reductionLow >= 0
      ? `Illustrative net particulate reduction: ${format(reductionLow)}–${format(Math.max(0, reductionHigh))}%`
      : reductionHigh <= 0
        ? `Illustrative net particulate increase: ${format(Math.abs(reductionHigh))}–${format(Math.abs(reductionLow))}%`
        : `Illustrative net particulate change: ${format(reductionLow)}% to ${format(reductionHigh)}%`;
    setText("scenario-impact", impact);
    sourceLabel.textContent = `Baseline source: ${baselineEdited ? "manual values" : baselineSource}. Scenario output is illustrative, not a forecast.`;
  };

  sliders.forEach((name) => {
    const input = document.getElementById(name);
    const output = document.getElementById(`${name}-value`);
    input.addEventListener("input", () => {
      output.value = `${input.value}%`;
      output.textContent = `${input.value}%`;
      calculate();
    });
  });

  const presets = {
    "preset-clean-commute": { traffic: 75, heavy: 80, dust: 25, crackers: 0, green: 35, winter: winterDefault },
    "preset-dust-control": { traffic: 10, heavy: 25, dust: 100, crackers: 0, green: 20, winter: winterDefault },
    "preset-winter": { traffic: 0, heavy: 0, dust: 0, crackers: 0, green: 0, winter: 100 },
    "preset-reset": { traffic: 0, heavy: 0, dust: 0, crackers: 0, green: 0, winter: winterDefault },
  };
  Object.entries(presets).forEach(([buttonId, levels]) => {
    document.getElementById(buttonId).addEventListener("click", () => {
      sliders.forEach((name) => {
        const input = document.getElementById(name);
        const output = document.getElementById(`${name}-value`);
        input.value = String(levels[name]);
        output.value = `${levels[name]}%`;
        output.textContent = `${levels[name]}%`;
      });
      calculate();
    });
  });

  [pm25Input, pm10Input].forEach((input) => {
    input.addEventListener("input", () => {
      baselineEdited = true;
      baselineStatus.textContent = "Using your manually entered baseline values.";
      sourceLabel.textContent = "Baseline source: manually entered particulate values.";
      calculate();
    });
  });

  growthInput.addEventListener("input", () => {
    const pm25 = readNumber(pm25Input);
    const pm10 = readNumber(pm10Input);
    if (pm25 === null || pm10 === null || pm25 < 0 || pm25 > 1000 || pm10 < 0 || pm10 > 1000) {
      updateProjection(null);
      return;
    }
    const particulateBaselineAqi = Math.max(particulateAqi(pm25, "pm25"), particulateAqi(pm10, "pm10"));
    const baselineAqi = !baselineEdited && modeledBaselineAqi !== null ? modeledBaselineAqi : particulateBaselineAqi;
    updateProjection(baselineAqi);
  });

  form.addEventListener("submit", (event) => event.preventDefault());

  const loadBaseline = async () => {
    try {
      const estimate = await window.fetchOpenMeteoEstimate();
      if (estimate.pm25 == null || estimate.pm10 == null || !Number.isFinite(Number(estimate.pm25)) || !Number.isFinite(Number(estimate.pm10))) {
        throw Error("Open-Meteo did not return numeric PM₂.₅ and PM₁₀ values.");
      }
      if (!baselineEdited) {
        const modelAqi = Number(estimate.aqi);
        modeledBaselineAqi = Number.isFinite(modelAqi) && modelAqi >= 0 ? Math.round(modelAqi) : null;
        pm25Input.value = estimate.pm25;
        pm10Input.value = estimate.pm10;
        baselineSource = `Open-Meteo modeled city estimate${estimate.timestamp ? ` (${estimate.timestamp})` : ""}`;
        baselineStatus.textContent = `Loaded current Open-Meteo modeled particulate and AQI values${estimate.timestamp ? ` for ${estimate.timestamp}` : ""}. The baseline AQI matches the Chandigarh model reading.`;
        sourceLabel.textContent = `Baseline source: ${baselineSource}.`;
        calculate();
      }
    } catch (error) {
      baselineStatus.textContent = `Could not load Open-Meteo baseline: ${error.message || "provider unavailable"}. Enter PM₂.₅ and PM₁₀ values manually to continue.`;
    }
  };

  loadBaseline();
})();
