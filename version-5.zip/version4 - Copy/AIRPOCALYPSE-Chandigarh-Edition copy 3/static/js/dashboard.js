(() => {
  const WAQI_REFRESH_INTERVAL_MS = 5 * 1000;
  const sourceSelect = document.getElementById("overview-source");
  const metrics = document.querySelector(".metric-grid");
  const tokenNode = document.getElementById("waqi-browser-token");
  let browserWaqiToken = null;
  try { browserWaqiToken = tokenNode ? JSON.parse(tokenNode.textContent || "null") : null; } catch { /* server proxy remains available */ }
  const setText = (id, value) => {
    const element = document.getElementById(id);
    if (element) element.textContent = value;
  };
  const setPageLoading = (isLoading) => {
    const page = document.querySelector(".page-container");
    if (!page) return;
    page.classList.toggle("is-data-loading", isLoading);
    page.setAttribute("aria-busy", String(isLoading));
  };
  const setState = (id, value) => {
    const element = document.getElementById(id);
    if (element?.lastChild) element.lastChild.textContent = ` ${value}`;
  };
  const numeric = (value) => value !== null && value !== undefined && value !== "" && Number.isFinite(Number(value)) ? Number(value) : null;
  const median = (readings) => {
    const values = readings.filter((value) => value !== null).sort((left, right) => left - right);
    if (!values.length) return null;
    const middle = Math.floor(values.length / 2);
    return values.length % 2 ? values[middle] : (values[middle - 1] + values[middle]) / 2;
  };
  const stationMedian = (stations, key) => {
    return median(stations.map((station) => numeric(station[key])).filter((value) => value !== null));
  };
  const particulateAqi = (concentration, pollutant) => {
    const breakpoints = {
      pm25: [[0, 9, 0, 50], [9.1, 35.4, 51, 100], [35.5, 55.4, 101, 150], [55.5, 125.4, 151, 200], [125.5, 225.4, 201, 300], [225.5, 325.4, 301, 500]],
      pm10: [[0, 54, 0, 50], [55, 154, 51, 100], [155, 254, 101, 150], [255, 354, 151, 200], [355, 424, 201, 300], [425, 604, 301, 500]],
    };
    const value = numeric(concentration);
    if (value === null || value < 0) return null;
    const normalized = pollutant === "pm25" ? Math.floor(value * 10) / 10 : Math.floor(value);
    for (const [low, high, indexLow, indexHigh] of breakpoints[pollutant] || []) {
      if (normalized >= low && normalized <= high) {
        return Math.round((indexHigh - indexLow) / (high - low) * (normalized - low) + indexLow);
      }
    }
    return 500;
  };
  const calculatedStationAqi = (station) => {
    const indexes = ["pm25", "pm10"].map((key) => particulateAqi(station.pollutants?.[key], key)).filter((value) => value !== null);
    return indexes.length ? Math.max(...indexes) : null;
  };
  const snapshot = metrics ? Object.fromEntries(["aqi", "pm25", "pm10"].map((key) => [key, {
    value: document.getElementById(`overview-${key}`)?.textContent || "—",
    state: document.getElementById(`overview-${key}-state`)?.lastChild?.textContent || " No reading available",
  }])) : null;
  const initialBanner = {
    status: document.getElementById("overview-source-status")?.textContent || "",
    title: document.getElementById("overview-data-title")?.textContent || "",
    description: document.getElementById("overview-data-description")?.textContent || "",
  };
  let waqiRefreshInProgress = false;

  const showValues = ({ aqi, pm25, pm10 }, label, status, description) => {
    setText("overview-aqi", aqi == null ? "—" : String(Math.round(aqi)));
    setText("overview-pm25", pm25 == null ? "—" : pm25.toFixed(1));
    setText("overview-pm10", pm10 == null ? "—" : pm10.toFixed(1));
    setState("overview-aqi-state", label);
    setState("overview-pm25-state", label);
    setState("overview-pm10-state", label);
    setText("overview-aqi-standard", "US EPA AQI");
    setText("overview-source-status", status);
    setText("overview-data-title", `${status.toLowerCase()} loaded`);
    setText("overview-data-description", description);
  };

  const browserWaqiStations = async () => {
    if (!browserWaqiToken) throw Error("WAQI is unavailable: configure WAQI_API_TOKEN for the browser fallback.");
    const searchQuery = new URLSearchParams({ keyword: "Chandigarh", token: browserWaqiToken });
    const searchResponse = await fetch(`https://api.waqi.info/search/?${searchQuery}`, { signal: AbortSignal.timeout(12000) });
    const searchPayload = await searchResponse.json();
    if (!searchResponse.ok || searchPayload.status !== "ok" || !Array.isArray(searchPayload.data)) throw Error("WAQI could not return Chandigarh stations.");
    return Promise.all(searchPayload.data.flatMap((item) => {
      const station = item.station || {};
      const name = station.name || "";
      if (!name.toLowerCase().includes("chandigarh") || !Number.isFinite(Number(item.uid))) return [];
      return [{ uid: item.uid, pm25: null, pm10: null, pollutants: null }];
    }).map(async (station) => {
      try {
        const query = new URLSearchParams({ token: browserWaqiToken });
        const response = await fetch(`https://api.waqi.info/feed/@${station.uid}/?${query}`, { signal: AbortSignal.timeout(10000) });
        const payload = await response.json();
        if (!response.ok || payload.status !== "ok" || !payload.data) return station;
        const measurements = payload.data.iaqi || {};
        return {
          pm25: measurements.pm25?.v,
          pm10: measurements.pm10?.v,
          pollutants: {
            pm25: measurements.pm25?.v,
            pm10: measurements.pm10?.v,
          },
        };
      } catch {
        return station;
      }
    }));
  };

  const loadWaqi = async () => {
    const params = new URLSearchParams({ south: "30.6", west: "76.6", north: "30.9", east: "76.9" });
    try {
      const response = await fetch(`/api/map/waqi-stations?${params}`, { signal: AbortSignal.timeout(15000) });
      const payload = await response.json();
      if (response.ok && payload.stations?.length) {
        const stations = payload.stations.filter((station) => station.name?.toLowerCase().includes("chandigarh"));
        return Promise.all(stations.map(async (station) => {
          if (!Number.isInteger(Number(station.uid))) return { ...station, pollutants: null };
          const detailResponse = await fetch(`/api/map/station/${encodeURIComponent(station.uid)}`, { signal: AbortSignal.timeout(12000) });
          const detail = await detailResponse.json();
          if (!detailResponse.ok) throw Error(detail.error || "WAQI pollutant measurements could not be loaded.");
          return {
            ...station,
            pollutants: detail.pollutants || {},
            pm25: detail.pollutants?.pm25 ?? null,
            pm10: detail.pollutants?.pm10 ?? null,
            calculated_aqi: detail.calculated_aqi,
          };
        }));
      }
    } catch { /* browser fallback below */ }
    return browserWaqiStations();
  };

  const loadSource = async (source) => {
    if (!metrics || !sourceSelect) return;
    if (source === "measured") {
      for (const key of ["aqi", "pm25", "pm10"]) {
        setText(`overview-${key}`, snapshot[key].value);
        setState(`overview-${key}-state`, snapshot[key].state.trim());
      }
      setText("overview-aqi-standard", "INDIA AQI");
      setText("overview-source-status", initialBanner.status);
      setText("overview-data-title", initialBanner.title);
      setText("overview-data-description", initialBanner.description);
      return;
    }
    if (waqiRefreshInProgress) return;

    waqiRefreshInProgress = true;
    setText("overview-source-status", `${source.toUpperCase()} LOADING`);
    setText("overview-data-description", "Fetching the selected current air-quality source.");
    setPageLoading(true);
    sourceSelect.disabled = true;
    try {
      const stations = await loadWaqi();
      const readings = {
        aqi: stationMedian(stations.map((station) => ({ aqi: station.calculated_aqi ?? calculatedStationAqi(station) })), "aqi"),
        pm25: stationMedian(stations, "pm25"),
        pm10: stationMedian(stations, "pm10"),
      };
      const count = stations.filter((station) => calculatedStationAqi(station) !== null || numeric(station.calculated_aqi) !== null).length;
      const label = `WAQI pollutant AQI (${count} station${count === 1 ? "" : "s"})`;
      if (readings.aqi == null) throw Error("WAQI returned no usable PM2.5 or PM10 measurements to calculate AQI for Chandigarh stations.");
      showValues(readings, label, "WAQI POLLUTANT AQI", `AQI is calculated from available WAQI station PM2.5 and PM10 measurements using US EPA particulate breakpoints; the highest available pollutant sub-index is used per station, then station AQIs are summarized by median. WAQI-reported AQI is not used.`);
    } catch (error) {
      setText("overview-source-status", `${source.toUpperCase()} UNAVAILABLE`);
      setText("overview-data-title", "Selected source unavailable");
      setText("overview-data-description", error.message || "Could not load the selected air-quality source.");
    } finally {
      waqiRefreshInProgress = false;
      sourceSelect.disabled = false;
      setPageLoading(false);
    }
  };

  if (sourceSelect) {
    sourceSelect.addEventListener("change", () => loadSource(sourceSelect.value));
    if (sourceSelect.value !== "measured") loadSource(sourceSelect.value);
    window.setInterval(() => {
      if (!document.hidden && sourceSelect.value === "waqi" && !waqiRefreshInProgress) loadSource("waqi");
    }, WAQI_REFRESH_INTERVAL_MS);
  }

  const dataNode = document.getElementById("trend-data");
  const canvas = document.getElementById("aqi-chart");
  if (!dataNode || !canvas) return;

  let trend;
  try {
    trend = JSON.parse(dataNode.textContent || "{}");
  } catch {
    return;
  }

  let trendChart = null;
  const draw = () => {
    if (!window.Chart || canvas.dataset.chartReady) return;
    canvas.dataset.chartReady = "true";
    const context = canvas.getContext("2d");
    const gradient = context.createLinearGradient(0, 0, 0, 210);
    gradient.addColorStop(0, "rgba(126, 219, 136, 0.2)");
    gradient.addColorStop(1, "rgba(126, 219, 136, 0)");

    trendChart = new Chart(context, {
      type: "line",
      data: {
        labels: trend.labels || [],
        datasets: [{
          label: "Measured AQI",
          data: trend.values || [],
          borderColor: "#8fdb91",
          backgroundColor: gradient,
          borderWidth: 2,
          pointRadius: (context) => context.raw === null ? 0 : 3,
          pointHoverRadius: 5,
          pointBackgroundColor: "#a7e8a2",
          pointBorderColor: "#122018",
          pointBorderWidth: 2,
          fill: true,
          tension: 0.35,
          spanGaps: false,
        }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        animation: { duration: 500 },
        interaction: { intersect: false, mode: "index" },
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: "#18231c",
            borderColor: "#38513d",
            borderWidth: 1,
            titleColor: "#9bab9e",
            bodyColor: "#e4eee5",
            padding: 10,
            callbacks: {
              label: (item) => {
                if (item.raw == null) return "No measured reading";
                return `Measured median AQI: ${item.raw}`;
              },
            },
          },
        },
        scales: {
          x: {
            grid: { display: false },
            border: { color: "#2b3930" },
            ticks: { color: "#7c8a80", maxTicksLimit: 8, font: { family: "DM Mono", size: 8 } },
          },
          y: {
            beginAtZero: true,
            suggestedMax: 100,
            grid: { color: "rgba(119, 143, 124, 0.12)" },
            border: { display: false },
            ticks: { color: "#718076", maxTicksLimit: 5, font: { family: "DM Mono", size: 8 } },
          },
        },
      },
    });
  };

  if (window.Chart) {
    draw();
  } else {
    const chartScript = document.querySelector('script[src*="chart.umd.min.js"]');
    if (chartScript) chartScript.addEventListener("load", draw, { once: true });
  }
})();
