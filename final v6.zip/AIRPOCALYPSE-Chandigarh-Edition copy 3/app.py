"""AIRPOCALYPSE: Chandigarh Edition — Flask application."""

from __future__ import annotations

import sqlite3
import os
import json
import math
import re
import html as html_module
import threading
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path
from statistics import median
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, build_opener, HTTPCookieProcessor, urlopen
from zoneinfo import ZoneInfo

from flask import Flask, jsonify, redirect, render_template, request, url_for

ROOT = Path(__file__).resolve().parent


def load_local_environment() -> None:
    """Read local ignored secrets for development; environment variables still win."""
    env_file = ROOT / ".env"
    if not env_file.exists():
        return
    for line in env_file.read_text(encoding="utf-8").splitlines():
        if line and not line.lstrip().startswith("#") and "=" in line:
            key, value = line.split("=", 1)
            os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


load_local_environment()
DATA_DIR = ROOT / "data"
DATABASE_PATH = DATA_DIR / "airpocalypse.sqlite3"
SCHEMA_PATH = DATA_DIR / "schema.sql"
INDIA_TZ = ZoneInfo("Asia/Kolkata")

app = Flask(__name__)
app.config["TEMPLATES_AUTO_RELOAD"] = True

WAQI_API = "https://api.waqi.info"

SIMULATOR_SOURCE_SHARES = {
    "vehicular_transport": (0.20, 0.35),
    "industry": (0.15, 0.30),
    "biomass_waste": (0.15, 0.25),
    "road_dust": (0.10, 0.20),
    "secondary_particles": (0.15, 0.25),
}


def fetch_json(url: str, timeout: float = 10.0) -> dict:
    try:
        with urlopen(Request(url, headers={"Accept": "application/json", "User-Agent": "AIRPOCALYPSE/1.0"}), timeout=timeout) as response:
            if response.status != 200:
                raise RuntimeError(f"Provider returned HTTP {response.status}.")
            data = json.load(response)
    except HTTPError as error:
        raise RuntimeError(f"Provider returned HTTP {error.code}.") from error
    except (URLError, TimeoutError) as error:
        raise RuntimeError("Provider could not be reached.") from error
    except json.JSONDecodeError as error:
        raise RuntimeError("Provider returned invalid JSON.") from error
    if not isinstance(data, dict):
        raise RuntimeError("Provider returned an invalid response.")
    return data


AQI_IN_URL = "https://www.aqi.in/in/dashboard/india/chandigarh"
AQI_IN_REFRESH_SECONDS = 10 * 60
AQI_IN_MAP_REFRESH_SECONDS = 60 * 60
AQI_IN_MAP_URL = "https://www.aqi.in/air-quality-map?map_type=aqi&loc_slug=india%2Fchandigarh%2Fchandigarh"
AQI_IN_MAP_API_URL = "https://apiserver.aqi.in/aqi/getAllMapLocations"
AQI_IN_CACHE: dict[str, object] = {"reading": None, "expires_at": None}
AQI_IN_MAP_CACHE: dict[str, object] = {"stations": None, "expires_at": None, "refreshed_at": None}
AQI_IN_MAP_FALLBACK_STATIONS = [
    {"uid": "india/chandigarh/chandigarh/new-dayal-bagh", "name": "New Dayal Bagh, Chandigarh", "latitude": 30.75, "longitude": 76.78, "aqi": 188.0, "pm25": 109.0, "pm10": 130.0, "source": "AQI.IN", "standard": "US EPA AQI", "station_url": "https://www.aqi.in/dashboard/india/chandigarh/chandigarh/new-dayal-bagh"},
]
AQI_IN_SCRAPER_STARTED = False
AQI_IN_SCRAPER_LOCK = threading.Lock()
AQI_IN_HISTORY_CACHE_PATH = DATA_DIR / "aqi_in_history.json"
AQI_IN_HISTORY_REFRESH_SECONDS = 24 * 60 * 60
AQI_IN_HISTORY_CACHE: dict[str, object] = {"daily": [], "hourly": [], "expires_at": None, "refreshed_at": None}
AQI_IN_HISTORY_LOCK = threading.Lock()
AQI_IN_MAP_SCRAPER_STARTED = False
AQI_IN_MAP_SCRAPER_LOCK = threading.Lock()


def scrape_aqi_in_chandigarh(force_refresh: bool = False) -> dict:
    now = datetime.now(timezone.utc)
    expires_at = AQI_IN_CACHE.get("expires_at")
    cached_reading = AQI_IN_CACHE.get("reading")
    if not force_refresh and isinstance(expires_at, datetime) and expires_at > now and isinstance(cached_reading, dict):
        return dict(cached_reading)
    """Scrape the public AQI.IN Chandigarh dashboard, without storing its values."""
    try:
        request = Request(AQI_IN_URL, headers={"Accept": "text/html,application/xhtml+xml", "User-Agent": "AIRPOCALYPSE/1.0 (+public-dashboard-read)"})
        with urlopen(request, timeout=15) as response:
            if response.status != 200:
                raise RuntimeError(f"AQI.IN returned HTTP {response.status}.")
            html_text = response.read().decode("utf-8", errors="replace")
    except HTTPError as error:
        raise RuntimeError(f"AQI.IN returned HTTP {error.code}.") from error
    except (URLError, TimeoutError) as error:
        raise RuntimeError("AQI.IN could not be reached.") from error

    dataset = None
    for match in re.finditer(r'<script[^>]*type=["\']application/ld\+json["\'][^>]*>(.*?)</script>', html_text, re.I | re.S):
        try:
            record = json.loads(html_module.unescape(match.group(1)))
        except json.JSONDecodeError:
            continue
        if isinstance(record, dict) and record.get("@type") == "Dataset" and "Chandigarh" in str(record.get("name", "")):
            dataset = record
            break

    meta_description = ""
    for meta_tag in re.findall(r"<meta\b[^>]*>", html_text, re.I):
        if re.search(r'name=["\']description["\']', meta_tag, re.I):
            content_match = re.search(r'content=["\']([^"\']*)["\']', meta_tag, re.I)
            if content_match:
                meta_description = html_module.unescape(content_match.group(1))
            break

    description = meta_description or (dataset.get("description", "") if dataset else html_text)
    aqi_match = (
        re.search(r"AQI[^0-9]{0,30}(\d{1,3})", description, re.I)
        or re.search(r"[\"']aqi[\"']\s*:\s*[\"']?(\d{1,3})", html_text, re.I)
    )
    pm25_match = re.search(r"PM2\.5[^0-9]{0,15}(\d+(?:\.\d+)?)", description, re.I)
    pm10_match = re.search(r"PM10[^0-9]{0,15}(\d+(?:\.\d+)?)", description, re.I)
    time_match = re.search(r"(?:Last Updated:\s*|last updated\s*)(\d{4}-\d{2}-\d{2}[^<]*?\d{2}:\d{2}:\d{2})", html_text, re.I)

    if not aqi_match:
        raise RuntimeError("AQI.IN did not expose a readable Chandigarh AQI value.")

    def to_float(match: re.Match | None) -> float | None:
        if not match:
            return None
        try:
            return float(match.group(1))
        except (TypeError, ValueError):
            return None

    reading = {
        "source": "AQI.IN",
        "standard": "US EPA AQI",
        "aqi": float(aqi_match.group(1)),
        "pm25": to_float(pm25_match),
        "pm10": to_float(pm10_match),
        "time": re.sub(r"\s*\(Local Time\).*", "", html_module.unescape(time_match.group(1))) if time_match else None,
        "url": AQI_IN_URL,
    }
    AQI_IN_CACHE["reading"] = dict(reading)
    AQI_IN_CACHE["expires_at"] = datetime.now(timezone.utc) + timedelta(seconds=AQI_IN_REFRESH_SECONDS)
    return reading


@app.get("/api/aqiin/chandigarh")
def api_aqi_in_chandigarh():
    try:
        force_refresh = request.args.get("refresh", "").lower() in {"1", "true", "yes"}
        return jsonify(scrape_aqi_in_chandigarh(force_refresh=force_refresh))
    except Exception as error:
        fallback = AQI_IN_CACHE.get("reading")
        if isinstance(fallback, dict):
            cached_fallback = dict(fallback)
            cached_fallback["cached"] = True
            cached_fallback["error"] = str(error)
            return jsonify(cached_fallback)
        return jsonify({"error": str(error), "source": "AQI.IN"}), 502


@app.context_processor
def inject_navigation():
    return {"nav_items": NAV_ITEMS, "waqi_browser_token": os.environ.get("WAQI_API_TOKEN")}


@app.get("/")
@app.get("/overview")
def dashboard():
    window = request.args.get("window", "30d")
    if window not in ("24h", "7d", "30d", "90d"):
        window = "30d"
    trend = get_trend(window)
    latest = None
    station_count = 0
    latest_is_stale = False
    with connect_db() as connection:
        station_count = connection.execute("SELECT COUNT(*) FROM monitoring_stations").fetchone()[0]
        row = connection.execute("""
            SELECT r.*, s.name AS station_name, s.area, ds.name AS source_name
            FROM readings r
            JOIN monitoring_stations s ON s.id = r.station_id
            LEFT JOIN data_sources ds ON ds.id = COALESCE(r.source_id, s.source_id)
            WHERE r.record_type = 'measured'
            ORDER BY r.observed_at DESC
            LIMIT 1
        """).fetchone()
        if row:
            latest = dict(row)
            try:
                observed = datetime.fromisoformat(latest["observed_at"].replace("Z", "+00:00"))
                if observed.tzinfo is None:
                    observed = observed.replace(tzinfo=INDIA_TZ)
                latest_is_stale = datetime.now(observed.tzinfo) - observed > timedelta(hours=3)
            except ValueError:
                latest_is_stale = True
    latest_time = display_time(latest["observed_at"]) if latest else None
    last_refreshed = datetime.now(INDIA_TZ).strftime("%d %b %Y · %I:%M:%S %p IST")
    return render_template(
        "dashboard.html", page_title="Overview", window=window,
        latest=latest, latest_time=latest_time, latest_is_stale=latest_is_stale,
        station_count=station_count, source_name=latest.get("source_name") if latest else None,
        cpcb_error=None, has_trend=any(value is not None for value in trend["values"]),
        trend_labels=trend["labels"], trend_values=trend["values"],
        waqi_browser_token=os.environ.get("WAQI_API_TOKEN"), trend_window=window, last_refreshed=last_refreshed,
        trend=trend, measured_records=[], latest_measurement=latest, aqi_reading=scrape_aqi_in_chandigarh_safe(),
    )


@app.get("/map")
@app.get("/air-map")
def air_map():
    stations = AQI_IN_MAP_FALLBACK_STATIONS
    cached = AQI_IN_MAP_CACHE.get("stations")
    if isinstance(cached, list) and cached:
        stations = cached
    return render_template("map.html", page_title="Air map", stations=stations,
                           waqi_browser_token=os.environ.get("WAQI_API_TOKEN"))


@app.get("/simulator")
def simulator():
    return render_template("simulator.html", page_title="Simulator", waqi_browser_token=None)


def requested_bounds() -> tuple[float, float, float, float]:
    try:
        south, west, north, east = (float(request.args[name]) for name in ("south", "west", "north", "east"))
    except (KeyError, TypeError, ValueError) as error:
        raise ValueError("Map bounds are missing or invalid.") from error
    if not (29.9 <= south < north <= 31.5 and 76.0 <= west < east <= 77.6):
        raise ValueError("Map bounds must be within the Chandigarh region.")
    return south, west, north, east

NAV_ITEMS = [
    {"label": "Overview", "endpoint": "dashboard", "icon": "overview"},
    {"label": "Air map", "endpoint": "air_map", "icon": "map"},
    {"label": "Simulator", "endpoint": "simulator", "icon": "simulator"},
    {"label": "Data sources", "endpoint": "sources", "icon": "sources"},
]


@contextmanager
def connect_db():
    """Open a short-lived SQLite connection with foreign keys enabled."""
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(DATABASE_PATH)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    try:
        yield connection
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()


def initialize_database() -> None:
    """Create the empty data model and register unconnected source candidates."""
    with connect_db() as connection:
        connection.executescript(SCHEMA_PATH.read_text(encoding="utf-8"))
        connection.executemany(
            """
            INSERT OR IGNORE INTO data_sources
                (name, organization, data_type, status, notes)
            VALUES (?, ?, 'measured', 'not_connected', ?)
            """,
            [
                (
                    "Central Pollution Control Board (CPCB)",
                    "Government of India",
                    "Potential official source. No feed is configured or verified.",
                ),
                (
                    "Chandigarh Pollution Control Committee (CPCC)",
                    "Chandigarh",
                    "Potential official source. No feed is configured or verified.",
                ),
            ],
        )


def parse_observed_at(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(INDIA_TZ)


def display_time(value: str | None) -> str:
    parsed = parse_observed_at(value)
    return parsed.strftime("%d %b %Y · %I:%M %p IST") if parsed else "Time unavailable"


def scrape_aqi_in_chandigarh_safe() -> dict | None:
    try:
        return scrape_aqi_in_chandigarh()
    except Exception:
        cached = AQI_IN_CACHE.get("reading")
        return dict(cached) if isinstance(cached, dict) else None


def load_aqi_in_history_cache() -> None:
    try:
        payload = json.loads(AQI_IN_HISTORY_CACHE_PATH.read_text(encoding="utf-8"))
        AQI_IN_HISTORY_CACHE["daily"] = payload.get("daily", []) if isinstance(payload, dict) else []
        AQI_IN_HISTORY_CACHE["hourly"] = payload.get("hourly", []) if isinstance(payload, dict) else []
        refreshed_at = payload.get("refreshed_at") if isinstance(payload, dict) else None
        if isinstance(refreshed_at, str):
            parsed = datetime.fromisoformat(refreshed_at.replace("Z", "+00:00"))
            AQI_IN_HISTORY_CACHE["refreshed_at"] = parsed.astimezone(timezone.utc) if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)
            AQI_IN_HISTORY_CACHE["expires_at"] = parsed.astimezone(timezone.utc) + timedelta(seconds=AQI_IN_HISTORY_REFRESH_SECONDS)
    except (FileNotFoundError, json.JSONDecodeError, OSError, ValueError):
        pass


def scrape_aqi_in_history() -> dict:
    load_aqi_in_history_cache()
    now = datetime.now(timezone.utc)
    expires_at = AQI_IN_HISTORY_CACHE.get("expires_at")
    cached_daily = AQI_IN_HISTORY_CACHE.get("daily")
    cached_hourly = AQI_IN_HISTORY_CACHE.get("hourly")
    if isinstance(expires_at, datetime) and expires_at > now:
        if (isinstance(cached_hourly, list) and cached_hourly) or (isinstance(cached_daily, list) and cached_daily):
            return {
                "daily": cached_daily if isinstance(cached_daily, list) else [],
                "hourly": cached_hourly if isinstance(cached_hourly, list) else [],
            }

    opener_headers = {"User-Agent": "Mozilla/5.0 AIRPOCALYPSE/1.0", "Accept": "text/html,application/json,*/*", "Referer": AQI_IN_MAP_URL}
    dashboard_url = "https://www.aqi.in/dashboard/india/chandigarh/chandigarh"
    hourly = []
    daily = []
    try:
        with urlopen(Request(dashboard_url, headers=opener_headers), timeout=20) as response:
            html_text = response.read().decode("utf-8", errors="replace")
        pairs = re.findall(r'<td>(\d{1,2}:\d{2}(?:am|pm))</td><td>(\d{1,3}(?:\.\d+)?)</td>', html_text, re.I)
        half_hourly = [{"time": time, "value": float(value)} for time, value in pairs]
        half_hourly = half_hourly[-48:] if len(half_hourly) >= 48 else half_hourly
        for index in range(0, len(half_hourly) - 1, 2):
            pair = half_hourly[index:index + 2]
            values = [item["value"] for item in pair]
            hourly.append({"time": pair[0]["time"], "value": round(median(values), 1)})
        embedded_daily = re.findall(
            r'["\'](?:day|date|aqiDate)["\']\s*:\s*["\'](\d{4}-\d{2}-\d{2})[^"\']*["\'].{0,160}?["\'](?:value|aqi)["\']\s*:\s*(\d+(?:\.\d+)?)',
            html_text, re.I | re.S,
        )
        daily = [{"day": day, "value": float(value)} for day, value in embedded_daily]
    except Exception:
        pass

    cookie_opener = build_opener(HTTPCookieProcessor())
    try:
        with cookie_opener.open(Request(dashboard_url, headers={**opener_headers, "Accept": "text/html,application/xhtml+xml", "Referer": "https://www.aqi.in/"}), timeout=15):
            pass
        calendar_url = "https://apiserver.aqi.in/aqi/v2/getAqiCalender?" + urlencode({
            "slug": "india/chandigarh/chandigarh", "slugType": "cityId", "sensorname": "aqi", "source": "web"
        })
        calendar_request = Request(calendar_url, headers={
            **opener_headers,
            "Accept": "application/json, text/plain, */*",
            "Origin": "https://www.aqi.in",
            "Referer": dashboard_url,
            "X-Requested-With": "XMLHttpRequest",
        })
        with cookie_opener.open(calendar_request, timeout=20) as response:
            payload = json.loads(response.read().decode("utf-8"))

        records = payload.get("data", []) if isinstance(payload, dict) else payload
        if not isinstance(records, list):
            records = []
        for item in records:
            if not isinstance(item, dict):
                continue
            day = item.get("day") or item.get("date") or item.get("aqiDate")
            value = item.get("value") if item.get("value") is not None else item.get("aqi")
            if isinstance(day, str) and isinstance(value, (int, float)):
                daily.append({"day": day[:10], "value": float(value)})

        if not daily:
            embedded = re.findall(
                r'["\'](?:day|date|aqiDate)["\']\s*:\s*["\'](\d{4}-\d{2}-\d{2})[^"\']*["\'].{0,160}?["\'](?:value|aqi)["\']\s*:\s*(\d+(?:\.\d+)?)',
                json.dumps(payload), re.I | re.S,
            )
            daily = [{"day": day, "value": float(value)} for day, value in embedded]
    except Exception:
        pass

    if daily:
        unique_daily = {}
        for item in daily:
            if isinstance(item, dict) and isinstance(item.get("day"), str) and re.fullmatch(r"\d{4}-\d{2}-\d{2}(?:T.*)?", item["day"]):
                day = item["day"][:10]
                unique_daily[day] = {"day": day, "value": float(item["value"])}
        daily = [unique_daily[day] for day in sorted(unique_daily)]

    if not daily and isinstance(cached_daily, list) and cached_daily:
        daily = cached_daily
    if hourly or daily:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        history_payload = {"daily": daily, "hourly": hourly, "refreshed_at": now.isoformat(), "source": "AQI.IN"}
        AQI_IN_HISTORY_CACHE_PATH.write_text(json.dumps(history_payload, ensure_ascii=False), encoding="utf-8")
        AQI_IN_HISTORY_CACHE["daily"] = daily
        AQI_IN_HISTORY_CACHE["hourly"] = hourly
        AQI_IN_HISTORY_CACHE["refreshed_at"] = now
        AQI_IN_HISTORY_CACHE["expires_at"] = now + timedelta(seconds=AQI_IN_HISTORY_REFRESH_SECONDS)

    return {"daily": daily if daily else (cached_daily if isinstance(cached_daily, list) else []), "hourly": hourly if hourly else (cached_hourly if isinstance(cached_hourly, list) else [])}


def get_trend(window: str = "30d") -> dict:
    window = window if window in ("24h", "7d", "30d", "90d") else "30d"
    if window in ("24h", "7d", "30d", "90d"):
        history = scrape_aqi_in_history()
        daily = history["daily"]
        hourly = history["hourly"]
        if hourly or daily:
            now = datetime.now(INDIA_TZ)
            if window == "24h":
                labels = [(now - timedelta(hours=24 - index)).strftime("%H:%M") for index in range(24)]
                if hourly:
                    source_values = [float(item["value"]) for item in hourly]
                    values = source_values[-24:] if len(source_values) >= 24 else ([None] * (24 - len(source_values)) + source_values)
                else:
                    latest = float(daily[-1]["value"])
                    values = [latest if index == 23 else None for index in range(24)]
            else:
                count = {"7d": 7, "30d": 30, "90d": 90}[window]
                labels = [(now - timedelta(days=count - 1 - index)).strftime("%d %b") for index in range(count)]
                values_by_day = {
                    item["day"][:10]: float(item["value"])
                    for item in daily
                    if isinstance(item, dict) and isinstance(item.get("day"), str)
                }
                values = [values_by_day.get((now - timedelta(days=count - 1 - index)).strftime("%Y-%m-%d")) for index in range(count)]
                # Missing dates stay null (for example, a not-yet-published current day).
                # Never substitute database or estimated values into scraped calendar points.
            return {"labels": labels, "values": values, "window": window, "source": "AQI.IN"}
    now = datetime.now(INDIA_TZ)
    if window == "24h":
        start = now - timedelta(hours=24)
        bucket_count = 24
        bucket_minutes = 60
    elif window == "7d":
        start = now - timedelta(days=7)
        bucket_count = 7
        bucket_minutes = 24 * 60
    elif window == "90d":
        start = now - timedelta(days=90)
        bucket_count = 90
        bucket_minutes = 24 * 60
    else:
        start = now - timedelta(days=30)
        bucket_count = 30
        bucket_minutes = 24 * 60

    labels = []
    values = [None] * bucket_count
    buckets = [[] for _ in range(bucket_count)]
    with connect_db() as connection:
        rows = connection.execute("""
            SELECT observed_at, aqi FROM readings
            WHERE record_type = 'measured' AND aqi IS NOT NULL
            ORDER BY observed_at ASC
        """).fetchall()
    for row in rows:
        try:
            observed = datetime.fromisoformat(row["observed_at"].replace("Z", "+00:00"))
            if observed.tzinfo is None:
                observed = observed.replace(tzinfo=INDIA_TZ)
            observed = observed.astimezone(INDIA_TZ)
        except ValueError:
            continue
        elapsed_minutes = (observed - start).total_seconds() / 60
        index = int(elapsed_minutes // bucket_minutes)
        if 0 <= index < bucket_count:
            buckets[index].append(float(row["aqi"]))
    for index in range(bucket_count):
        bucket_start = start + timedelta(minutes=bucket_minutes * index)
        labels.append(bucket_start.strftime("%H:%M" if window == "24h" else "%d %b"))
        if buckets[index]:
            values[index] = round(median(buckets[index]), 1)
    return {"labels": labels, "values": values, "window": window}


@app.get("/api/aqi/trend/<window>")
def api_aqi_trend(window: str):
    return jsonify(get_trend(window))


@app.get("/api/map/aqiin-stations")
def api_aqi_in_map_stations():
    force_refresh = request.args.get("refresh") == "1"
    expires_at = AQI_IN_MAP_CACHE.get("expires_at")
    if force_refresh or not isinstance(AQI_IN_MAP_CACHE.get("stations"), list) or not isinstance(expires_at, datetime) or expires_at <= datetime.now(timezone.utc):
        refresh_aqi_in_map_cache()

    cached = AQI_IN_MAP_CACHE.get("stations")
    stations = cached if isinstance(cached, list) and cached else AQI_IN_MAP_FALLBACK_STATIONS
    return jsonify({
        "stations": stations,
        "source": "AQI.IN",
        "status": "live" if isinstance(cached, list) and cached else "snapshot",
        "refreshed_at": AQI_IN_MAP_CACHE.get("refreshed_at").isoformat() if isinstance(AQI_IN_MAP_CACHE.get("refreshed_at"), datetime) else None,
    })


def particulate_aqi(concentration: float, pollutant: str) -> int:
    """Convert particulate concentration to a US EPA AQI value."""
    breakpoints = {
        "pm25": [
            (0.0, 9.0, 0, 50),
            (9.1, 35.4, 51, 100),
            (35.5, 55.4, 101, 150),
            (55.5, 125.4, 151, 200),
            (125.5, 225.4, 201, 300),
            (225.5, 325.4, 301, 500),
        ],
        "pm10": [
            (0, 54, 0, 50),
            (55, 154, 51, 100),
            (155, 254, 101, 150),
            (255, 354, 151, 200),
            (355, 424, 201, 300),
            (425, 604, 301, 500),
        ],
    }
    if pollutant not in breakpoints:
        raise ValueError("Pollutant must be pm25 or pm10.")
    concentration = max(0.0, concentration)
    if pollutant == "pm25":
        concentration = int(concentration * 10) / 10
    else:
        concentration = int(concentration)
    for low, high, index_low, index_high in breakpoints[pollutant]:
        if low <= concentration <= high:
            return round((index_high - index_low) / (high - low) * (concentration - low) + index_low)
    return 500


def simulate_air_quality(pm25: float, pm10: float, vehicular_transport: int, industry: int, biomass_waste: int, road_dust: int, secondary_particles: int, baseline_aqi: float | None = None) -> dict:
    """Calculate an AQI screening estimate from the five explicit source factors."""
    control_values = {
        "vehicular_transport": vehicular_transport,
        "industry": industry,
        "biomass_waste": biomass_waste,
        "road_dust": road_dust,
        "secondary_particles": secondary_particles,
    }
    reduction_low = sum(control_values[name] / 100 * SIMULATOR_SOURCE_SHARES[name][0] for name in control_values)
    reduction_high = sum(control_values[name] / 100 * SIMULATOR_SOURCE_SHARES[name][1] for name in control_values)
    reduction_low = min(1.0, reduction_low)
    reduction_high = min(1.0, reduction_high)
    pm25_low = pm25 * (1 - reduction_high)
    pm25_high = pm25 * (1 - reduction_low)
    pm10_low = pm10 * (1 - reduction_high)
    pm10_high = pm10 * (1 - reduction_low)
    low_aqi = max(particulate_aqi(pm25_low, "pm25"), particulate_aqi(pm10_low, "pm10"))
    high_aqi = max(particulate_aqi(pm25_high, "pm25"), particulate_aqi(pm10_high, "pm10"))
    baseline_aqi = int(round(baseline_aqi)) if baseline_aqi is not None else max(particulate_aqi(pm25, "pm25"), particulate_aqi(pm10, "pm10"))
    all_five_fully_controlled = all(control_values[name] == 100 for name in control_values)
    if all_five_fully_controlled:
        scenario_low_aqi = 40
        scenario_high_aqi = 60
    elif baseline_aqi <= 40:
        scenario_low_aqi = baseline_aqi
        scenario_high_aqi = baseline_aqi
    else:
        adjustable_aqi = max(0, baseline_aqi - 50)
        if adjustable_aqi <= 0:
            scenario_low_aqi = baseline_aqi
            scenario_high_aqi = baseline_aqi
        else:
            scenario_low_aqi = round(min(baseline_aqi, max(40, baseline_aqi - adjustable_aqi * reduction_high)), 1)
            scenario_high_aqi = round(min(baseline_aqi, max(40, baseline_aqi - adjustable_aqi * reduction_low)), 1)
            if scenario_low_aqi > scenario_high_aqi:
                scenario_low_aqi, scenario_high_aqi = scenario_high_aqi, scenario_low_aqi
    return {
        "baseline": {"pm25": round(pm25, 1), "pm10": round(pm10, 1), "aqi": baseline_aqi},
        "scenario": {
            "pm25": {"low": round(pm25_low, 1), "high": round(pm25_high, 1), "scenario_low": round(pm25_low, 1), "scenario_high": round(pm25_high, 1)},
            "pm10": {"low": round(pm10_low, 1), "high": round(pm10_high, 1), "scenario_low": round(pm10_low, 1), "scenario_high": round(pm10_high, 1)},
            "aqi_low": scenario_low_aqi,
            "aqi_high": scenario_high_aqi,
            "aqi": round((scenario_low_aqi + scenario_high_aqi) / 2, 1),
            "aqi_range": {"scenario_low": scenario_low_aqi, "scenario_high": scenario_high_aqi},
        },
        "assumptions": {
            "basis": "Illustrative screening model based only on the five source contribution ranges.",
            "vehicular_transport": "20%–35% contribution range",
            "industry": "15%–30% contribution range",
            "biomass_waste": "15%–25% contribution range",
            "road_dust": "10%–20% contribution range",
            "secondary_particles": "15%–25% contribution range",
            "response": "Expected reduction is proportional to each selected 0–100% control level; weather and chemistry are not modeled.",
            "natural_base_floor": "AQI 40–60 natural range; reductions apply to AQI above the midpoint floor of 50."
        },
    }

@app.post("/api/aqi/calendar-import")
def import_aqi_calendar():
    payload = request.get_json(silent=True)
    records = payload.get("daily") if isinstance(payload, dict) else payload
    if not isinstance(records, list):
        return jsonify({"error": "daily records required"}), 400

    unique = {}
    for item in records:
        if not isinstance(item, dict):
            continue
        day = item.get("day")
        value = item.get("value")
        if isinstance(day, str) and re.fullmatch(r"\d{4}-\d{2}-\d{2}", day[:10]):
            try:
                unique[day[:10]] = {"day": day[:10], "value": float(value)}
            except (TypeError, ValueError):
                continue

    daily = [unique[day] for day in sorted(unique)][-90:]
    if len(daily) < 2:
        return jsonify({"error": "no valid calendar records"}), 400

    now = datetime.now(timezone.utc)
    history_payload = {"daily": daily, "hourly": [], "refreshed_at": now.isoformat(), "source": "AQI.IN Air Quality Calendar"}
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    AQI_IN_HISTORY_CACHE_PATH.write_text(json.dumps(history_payload, ensure_ascii=False), encoding="utf-8")
    AQI_IN_HISTORY_CACHE.update({"daily": daily, "hourly": [], "refreshed_at": now, "expires_at": now + timedelta(seconds=AQI_IN_HISTORY_REFRESH_SECONDS)})
    response = jsonify({"imported": len(daily), "first": daily[0]["day"], "last": daily[-1]["day"]})
    response.headers["Access-Control-Allow-Origin"] = "https://www.aqi.in"
    return response


@app.post("/api/simulate")
def simulate_scenario():
    payload = request.get_json(silent=True)
    if not isinstance(payload, dict):
        return jsonify({"error": "A JSON scenario payload is required."}), 400
    fields = ("pm25", "pm10", "vehicular_transport", "industry", "biomass_waste", "road_dust", "secondary_particles")
    alias_fields = {"vehicular_transport": "traffic", "road_dust": "dust"}
    for field in fields[2:]:
        if field not in payload and alias_fields.get(field) in payload:
            payload[field] = payload[alias_fields[field]]
    values = {}
    for field in fields:
        if field in fields[2:] and field not in payload:
            values[field] = 0.0
            continue
        try:
            values[field] = float(payload[field])
        except (KeyError, TypeError, ValueError):
            return jsonify({"error": f"{field} must be a number."}), 400
        if not math.isfinite(values[field]):
            return jsonify({"error": f"{field} must be finite."}), 400
    if not 0 <= values["pm25"] <= 1000 or not 0 <= values["pm10"] <= 1000:
        return jsonify({"error": "PM2.5 and PM10 must be between 0 and 1000 µg/m³."}), 400
    for field in fields[2:]:
        if not 0 <= values[field] <= 100:
            return jsonify({"error": f"{field} must be between 0 and 100%."}), 400
    baseline_aqi = None
    if "baseline_aqi" in payload:
        try:
            baseline_aqi = float(payload["baseline_aqi"])
        except (TypeError, ValueError):
            return jsonify({"error": "baseline_aqi must be a number."}), 400
        if not math.isfinite(baseline_aqi) or not 0 <= baseline_aqi <= 500:
            return jsonify({"error": "baseline_aqi must be between 0 and 500."}), 400
    return jsonify(simulate_air_quality(values["pm25"], values["pm10"], round(values["vehicular_transport"]), round(values["industry"]), round(values["biomass_waste"]), round(values["road_dust"]), round(values["secondary_particles"]), baseline_aqi))

@app.get("/scenarios")
def scenarios():
    return redirect(url_for("simulator"))


@app.get("/sources")
def sources():
    with connect_db() as connection:
        data_sources = [
            dict(row)
            for row in connection.execute(
                "SELECT * FROM data_sources ORDER BY name COLLATE NOCASE"
            ).fetchall()
        ]
    waqi_connected = bool(os.environ.get("WAQI_API_TOKEN"))
    data_sources.append({
        "name": "World Air Quality Index (WAQI)",
        "organization": "World Air Quality Index Project",
        "data_type": "measured",
        "status": "connected" if waqi_connected else "not_connected",
        "notes": "Live station observations and pollutant details; reported AQI uses the US EPA scale.",
    })
    data_sources.sort(key=lambda source: source["name"].casefold())
    return render_template(
        "sources.html",
        page_title="Data sources",
        data_sources=data_sources,
        waqi_connected=waqi_connected,
    )


@app.get("/healthz")
def healthz():
    return jsonify({"status": "ok", "application": "AIRPOCALYPSE: Chandigarh Edition"})


initialize_database()


def start_aqi_in_scraper() -> None:
    """Refresh the public AQI.IN snapshot every 10 minutes in the background."""
    global AQI_IN_SCRAPER_STARTED
    with AQI_IN_SCRAPER_LOCK:
        if AQI_IN_SCRAPER_STARTED:
            return
        AQI_IN_SCRAPER_STARTED = True

    def refresh_loop() -> None:
        while True:
            try:
                scrape_aqi_in_chandigarh()
            except Exception as error:
                app.logger.warning("AQI.IN background scrape failed: %s", error)
            threading.Event().wait(AQI_IN_REFRESH_SECONDS)

    thread = threading.Thread(target=refresh_loop, name="aqi-in-10-minute-scraper", daemon=True)
    thread.start()


start_aqi_in_scraper()


def start_aqi_in_history_scraper() -> None:
    """Refresh the AQI.IN calendar once each day, after IST midnight."""
    def refresh_loop() -> None:
        while True:
            try:
                scrape_aqi_in_history()
            except Exception as error:
                app.logger.warning("AQI.IN history refresh failed: %s", error)

            now_ist = datetime.now(INDIA_TZ)
            next_midnight = (now_ist + timedelta(days=1)).replace(hour=0, minute=5, second=0, microsecond=0)
            threading.Event().wait(max(60, (next_midnight - now_ist).total_seconds()))

    thread = threading.Thread(target=refresh_loop, name="aqi-in-daily-history-scraper", daemon=True)
    thread.start()


start_aqi_in_history_scraper()


def refresh_aqi_in_map_cache() -> bool:
    try:
        reading = scrape_aqi_in_chandigarh(force_refresh=True)
        station = dict(AQI_IN_MAP_FALLBACK_STATIONS[0])
        station.update({
            "aqi": reading["aqi"],
            "pm25": reading.get("pm25"),
            "pm10": reading.get("pm10"),
            "timestamp": reading.get("time"),
        })
        now = datetime.now(timezone.utc)
        AQI_IN_MAP_CACHE.update({"stations": [station], "expires_at": now + timedelta(seconds=AQI_IN_MAP_REFRESH_SECONDS), "refreshed_at": now})
        return True
    except Exception as error:
        app.logger.warning("AQI.IN map refresh failed: %s", error)
        AQI_IN_MAP_CACHE["refreshed_at"] = datetime.now(timezone.utc)
        return False


def start_aqi_in_map_scraper() -> None:
    """Keep the Air Map data fresh and retry failed upstream refreshes hourly."""
    global AQI_IN_MAP_SCRAPER_STARTED
    with AQI_IN_MAP_SCRAPER_LOCK:
        if AQI_IN_MAP_SCRAPER_STARTED:
            return
        AQI_IN_MAP_SCRAPER_STARTED = True

    def refresh_loop() -> None:
        refresh_aqi_in_map_cache()
        while True:
            threading.Event().wait(AQI_IN_MAP_REFRESH_SECONDS)
            refresh_aqi_in_map_cache()

    thread = threading.Thread(target=refresh_loop, name="aqi-in-map-hourly-scraper", daemon=True)
    thread.start()


start_aqi_in_map_scraper()

if __name__ == "__main__":
    app.run(
        host="0.0.0.0",
        port=int(os.environ.get("PORT", "8000")),
        debug=False,
    )
