# AIRPOCALYPSE: Chandigarh Edition

A Flask application for viewing Chandigarh air-quality observations while keeping measurements, estimates, and simulations clearly distinct.

## Run & Operate

- `python app.py` — run the Flask application (port 5000, or the `PORT` environment value)
- `python -m unittest discover -s tests` — run the app's automated tests
- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- Python 3.13, Flask, Jinja templates, SQLite
- Plain HTML, CSS, and vanilla JavaScript; Leaflet maps and Chart.js charts via CDN
- No React, Node frontend, TypeScript, or frontend build process for AIRPOCALYPSE
- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `app.py` — Flask routes, SQLite access, and dashboard data preparation
- `templates/` — reusable base layout and Jinja pages
- `static/css/style.css` — responsive dark interface
- `static/js/` — dashboard chart, map, and simulator preview interactions
- `data/schema.sql` — SQLite tables and indexes
- The SQLite database is created at runtime and excluded from Git

## Architecture decisions

- The initial data store is SQLite as requested; no additional database service is needed.
- The app starts with no station or reading records. Candidate organizations are explicitly marked as not connected.
- The AQI trend and map use measured records only. Estimates and simulations have separate data labels.
- The simulator provides clearly labelled illustrative scenario estimates; no separate scenario-comparison page is offered.

## Product

- Dashboard with latest available measured AQI, PM2.5, PM10, station records, and historical trend.
- Leaflet map centered on Chandigarh that only plots monitoring stations with entered coordinates.
- Data-source register describing connection status and the separation of measured, estimated, and simulated information.
- The simulator keeps modelled outputs separate from measured station readings.

## User preferences

- The user requires Flask, Jinja, plain HTML/CSS/vanilla JavaScript, SQLite, Leaflet, and Chart.js; no React or frontend build process.
- Never invent Chandigarh pollution readings, monitoring-station locations, or simulation outcomes. Clearly label temporary demonstration data.

## Gotchas

- A missing reading is displayed as unavailable, never as zero or as evidence of clean air.
- The Leaflet map center is geographic context, not a monitoring-station marker.
- The map defaults to the official CPCB real-time National AQI dataset. To enable it, create a data.gov.in account, request/generate an API key for resource `3b01bcb8-0b14-4abf-b6f2-c1bfd384ba69`, then start the server with `CPCB_DATA_GOV_API_KEY` set in its environment. The key is used only by Flask and is never sent to the browser.
- WAQI is an optional secondary station source. Obtain a token through [WAQI's API registration](https://aqicn.org/api/), set `WAQI_API_TOKEN` in the server environment, and restart. WAQI readings retain the provider's US EPA AQI label and are never presented as CPCB National AQI.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
