﻿(() => {
  const element = document.getElementById("air-map");
  const setPageLoading = (isLoading) => {
    const page = document.querySelector(".page-container");
    if (!page) return;
    page.classList.toggle("is-data-loading", isLoading);
    page.setAttribute("aria-busy", String(isLoading));
  };
  const setText = (id, value) => { const node = document.getElementById(id); if (node) node.textContent = value; };
  if (!element || !window.L) {
    setPageLoading(false);
    setText("map-source-state", "MAP UNAVAILABLE");
    setText("station-count", "0 stations");
    return;
  }
  const escapeHtml = (value) => String(value ?? "").replace(/[&<>"']/g, (char) => ({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"})[char]);
  const cityBounds = L.latLngBounds([[30.65, 76.70], [30.81, 76.85]]);
  const map = L.map(element, { maxBounds: cityBounds, maxBoundsViscosity: 1 }).setView([30.7333, 76.7794], 12);
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 19, attribution: "&copy; OpenStreetMap contributors" }).addTo(map);
  const fit = () => { map.invalidateSize(); const minZoom = map.getBoundsZoom(cityBounds, false, L.point(16, 16)); map.setMinZoom(minZoom); if (map.getZoom() < minZoom) map.fitBounds(cityBounds, { padding: [16, 16] }); map.panInsideBounds(cityBounds, { animate: false }); };
  fit();
  let observations;
  const colour = (aqi) => aqi == null ? "#7b8790" : aqi <= 50 ? "#00a65a" : aqi <= 100 ? "#ffde33" : aqi <= 150 ? "#ff9933" : aqi <= 200 ? "#cc0033" : aqi <= 300 ? "#8f3f97" : "#7e0023";
  const stationNode = document.getElementById("station-data");
  let initialStations = [];
  try { initialStations = stationNode ? (JSON.parse(stationNode.textContent || "null")?.stations || []) : []; } catch { initialStations = []; }
  const loadAqiIn = async () => {
    const refresh = document.getElementById("refresh-map"); if (refresh) refresh.disabled = true;
    setPageLoading(true);
    setText("map-source-state", "CONNECTING AQI.IN");
    try {
      const stationResponse = await fetch("/api/map/aqiin-stations", { cache: "no-store", signal: AbortSignal.timeout(20000), headers: { Accept: "application/json" } });
      const stationPayload = await stationResponse.json();
      let stations = Array.isArray(stationPayload.stations) ? stationPayload.stations : initialStations;
      stations = stations.map((station) => ({
        ...station,
        latitude: Number(station.latitude ?? station.lat ?? station.location?.latitude),
        longitude: Number(station.longitude ?? station.lng ?? station.lon ?? station.location?.longitude),
        aqi: Number(station.aqi ?? station.aqi_value ?? station.current_aqi),
        timestamp: (station.timestamp || station.time || "").toString().toLowerCase().includes("map snapshot") ? "" : (station.timestamp || station.time || ""),
      })).filter((station) => Number.isFinite(station.latitude) && Number.isFinite(station.longitude) && Number.isFinite(station.aqi));
      if (!stations.length) throw new Error("AQI.IN returned no usable station locations");
      if (observations) observations.clearLayers(); else observations = L.layerGroup().addTo(map);
      stations.forEach((station) => {
        const aqi = Math.round(station.aqi);
        const name = station.name || station.location_name || station.city || "AQI.IN station";
        const icon = L.divIcon({ className: "air-marker", html: `<span style="--aqi-colour:${colour(aqi)}"></span>`, iconSize: [18, 18], iconAnchor: [9, 9] });
        const marker = L.marker([station.latitude, station.longitude], { icon, title: name }).addTo(observations);
        const stationTime = station.timestamp || station.time;
        marker.bindPopup(`<div class="map-popup-title">${escapeHtml(name)}</div><div class="map-popup-subtitle">AQI.IN · US EPA AQI</div><div class="map-popup-values"><span>AQI <b>${aqi}</b></span></div>${stationTime ? `<div class="map-popup-time">${escapeHtml(stationTime)}</div>` : ""}`);
      });
      const list = document.getElementById("live-station-list");
      if (list) list.innerHTML = stations.map((station) => {
        const aqi = Math.round(station.aqi);
        const name = station.name || station.location_name || station.city || "AQI.IN station";
        const stationTime = station.timestamp || station.time;
        return `<article class="station-row"><span class="station-marker" style="background:${colour(aqi)}"></span><div class="station-row-main"><strong>${escapeHtml(name)}</strong><div class="station-readings"><span>US EPA AQI <b>${aqi}</b></span></div>${stationTime ? `<small>${escapeHtml(stationTime)}</small>` : ""}</div></article>`;
      }).join("");
      setText("station-count", `${stations.length} station${stations.length === 1 ? "" : "s"}`);
      setText("map-source-state", "AQI.IN LIVE MAP");
      setText("map-last-updated", "Updated from AQI.IN map feed");
      const notice = document.getElementById("map-notice"); if (notice) notice.innerHTML = '<span class="note-mark">i</span><span>AQI.IN map locations are shown as station markers. No heatmap or interpolated citywide values are displayed.</span>';
    } catch (error) {
      setText("map-source-state", "AQI.IN UNAVAILABLE"); setText("station-count", "0 stations");
      const list = document.getElementById("live-station-list"); if (list) list.innerHTML = '<div class="station-list-empty"><span class="empty-list-dash">—</span><p>AQI.IN could not provide station locations.</p></div>';
      const notice = document.getElementById("map-notice"); if (notice) notice.innerHTML = '<span class="note-mark">!</span><span>AQI.IN is currently unavailable.</span>';
    } finally {
      if (refresh) refresh.disabled = false;
      setPageLoading(false);
    }
  };
  document.getElementById("toggle-stations")?.addEventListener("click", (event) => { if (!observations) return; const on = event.currentTarget.getAttribute("aria-pressed") !== "true"; observations[on ? "addTo" : "removeFrom"](map); event.currentTarget.setAttribute("aria-pressed", String(on)); event.currentTarget.textContent = `Station markers: ${on ? "on" : "off"}`; });
  document.getElementById("refresh-map")?.addEventListener("click", loadAqiIn);
  loadAqiIn();
  window.setInterval(() => { if (!document.hidden) loadAqiIn(); }, 60 * 60 * 1000);
})();
