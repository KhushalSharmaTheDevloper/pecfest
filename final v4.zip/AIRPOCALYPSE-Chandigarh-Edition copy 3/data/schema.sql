PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS data_sources (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    organization TEXT NOT NULL,
    data_type TEXT NOT NULL CHECK (data_type IN ('measured', 'estimated')),
    status TEXT NOT NULL CHECK (status IN ('not_connected', 'connected')),
    notes TEXT NOT NULL DEFAULT '',
    source_url TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS monitoring_stations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    area TEXT,
    station_code TEXT UNIQUE,
    latitude REAL NOT NULL CHECK (latitude BETWEEN -90 AND 90),
    longitude REAL NOT NULL CHECK (longitude BETWEEN -180 AND 180),
    source_id INTEGER REFERENCES data_sources(id),
    verified_at TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS readings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    station_id INTEGER NOT NULL REFERENCES monitoring_stations(id) ON DELETE CASCADE,
    source_id INTEGER REFERENCES data_sources(id),
    observed_at TEXT NOT NULL,
    aqi REAL CHECK (aqi IS NULL OR aqi >= 0),
    pm25 REAL CHECK (pm25 IS NULL OR pm25 >= 0),
    pm10 REAL CHECK (pm10 IS NULL OR pm10 >= 0),
    record_type TEXT NOT NULL CHECK (
        record_type IN ('measured', 'estimated', 'simulation')
    ),
    source_timestamp TEXT,
    recorded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    notes TEXT NOT NULL DEFAULT ''
);

CREATE INDEX IF NOT EXISTS idx_readings_station_time
    ON readings(station_id, observed_at DESC);
CREATE INDEX IF NOT EXISTS idx_readings_type_time
    ON readings(record_type, observed_at DESC);
