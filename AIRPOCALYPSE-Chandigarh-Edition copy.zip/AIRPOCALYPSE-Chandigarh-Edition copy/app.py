"""AIRPOCALYPSE: Chandigarh Edition — Flask application."""

from __future__ import annotations

import sqlite3
import os
import json
from functools import lru_cache
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path
from statistics import median
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from zoneinfo import ZoneInfo

from flask import Flask, jsonify, render_template, request

ROOT = Path(__file__).resolve().parent


def load_local_environment() -> None:
    """Read local ignored secrets for development; environment variables still win."""
    env_file = ROOT / ".env"
    if not env_file.exists():
        return
    for line in env_file.read_text(encoding="utf-8").splitlines():
        if line and not line.lstrip().startswith("#") and "=" in line:
            key, value = line.split("=", 1)
            os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


load_local_environment()
DATA_DIR = ROOT / "data"
DATABASE_PATH = DATA_DIR / "airpocalypse.sqlite3"
SCHEMA_PATH = DATA_DIR / "schema.sql"
INDIA_TZ = ZoneInfo("Asia/Kolkata")

app = Flask(__name__)
app.config["TEMPLATES_AUTO_RELOAD"] = True

WAQI_API = "https://api.waqi.info"
OPEN_METEO_AIR_QUALITY_API = "https://air-quality-api.open-meteo.com/v1/air-quality"


def fetch_json(url: str, timeout: float = 10.0) -> dict:
    try:
        with urlopen(Request(url, headers={"Accept": "application/json", "User-Agent": "AIRPOCALYPSE/1.0"}), timeout=timeout) as response:
            if response.status != 200:
                raise RuntimeError(f"Provider returned HTTP {response.status}.")
            data = json.load(response)
    except HTTPError as error:
        raise RuntimeError(f"Provider returned HTTP {error.code}.") from error
    except (URLError, TimeoutError) as error:
        raise RuntimeError("Provider could not be reached.") from error
    except json.JSONDecodeError as error:
        raise RuntimeError("Provider returned invalid JSON.") from error
    if not isinstance(data, dict):
        raise RuntimeError("Provider returned an invalid response.")
    return data


def requested_bounds() -> tuple[float, float, float, float]:
    try:
        south, west, north, east = (float(request.args[name]) for name in ("south", "west", "north", "east"))
    except (KeyError, TypeError, ValueError) as error:
        raise ValueError("Map bounds are missing or invalid.") from error
    if not (29.9 <= south < north <= 31.5 and 76.0 <= west < east <= 77.6):
        raise ValueError("Map bounds must be within the Chandigarh region.")
    return south, west, north, east

NAV_ITEMS = [
    {"label": "Overview", "endpoint": "dashboard", "icon": "overview"},
    {"label": "Air map", "endpoint": "air_map", "icon": "map"},
    {"label": "Simulator", "endpoint": "simulator", "icon": "simulator"},
    {"label": "Compare scenarios", "endpoint": "scenarios", "icon": "compare"},
    {"label": "Data sources", "endpoint": "sources", "icon": "sources"},
]


@contextmanager
def connect_db():
    """Open a short-lived SQLite connection with foreign keys enabled."""
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(DATABASE_PATH)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    try:
        yield connection
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()


def initialize_database() -> None:
    """Create the empty data model and register unconnected source candidates."""
    with connect_db() as connection:
        connection.executescript(SCHEMA_PATH.read_text(encoding="utf-8"))
        connection.executemany(
            """
            INSERT OR IGNORE INTO data_sources
                (name, organization, data_type, status, notes)
            VALUES (?, ?, 'measured', 'not_connected', ?)
            """,
            [
                (
                    "Central Pollution Control Board (CPCB)",
                    "Government of India",
                    "Potential official source. No feed is configured or verified.",
                ),
                (
                    "Chandigarh Pollution Control Committee (CPCC)",
                    "Chandigarh",
                    "Potential official source. No feed is configured or verified.",
                ),
            ],
        )


def parse_observed_at(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(INDIA_TZ)


def display_time(value: str | None) -> str:
    parsed = parse_observed_at(value)
    return parsed.strftime("%d %b %Y · %I:%M %p IST") if parsed else "Time unavailable"


def get_latest_reading() -> sqlite3.Row | None:
    with connect_db() as connection:
        return connection.execute(
            """
            SELECT r.id, r.station_id, r.observed_at, r.aqi, r.pm25, r.pm10,
                   s.name AS station_name, s.area, d.name AS source_name
            FROM readings AS r
            JOIN monitoring_stations AS s ON s.id = r.station_id
            LEFT JOIN data_sources AS d ON d.id = r.source_id
            WHERE r.record_type = 'measured'
            ORDER BY datetime(r.observed_at) DESC, r.id DESC
            LIMIT 1
            """
        ).fetchone()


def get_station_summaries() -> list[dict]:
    with connect_db() as connection:
        rows = connection.execute(
            """
            SELECT s.id, s.name, s.area, s.latitude, s.longitude,
                   s.station_code, d.name AS source_name,
                   r.observed_at, r.aqi, r.pm25, r.pm10
            FROM monitoring_stations AS s
            LEFT JOIN data_sources AS d ON d.id = s.source_id
            LEFT JOIN readings AS r ON r.id = (
                SELECT recent.id
                FROM readings AS recent
                WHERE recent.station_id = s.id
                  AND recent.record_type = 'measured'
                ORDER BY datetime(recent.observed_at) DESC, recent.id DESC
                LIMIT 1
            )
            ORDER BY s.name COLLATE NOCASE
            """
        ).fetchall()
    return [
        {
            **dict(row),
            "observed_at_display": display_time(row["observed_at"]),
        }
        for row in rows
    ]


def get_trend(window: str) -> tuple[list[str], list[float | None]]:
    """Return daily/hourly medians from measured AQI rows only."""
    now = datetime.now(timezone.utc)
    if window == "90d":
        local_start = now.astimezone(INDIA_TZ).date() - timedelta(days=90)
        labels = [(local_start + timedelta(days=index)).strftime("%d %b") for index in range(90)]
        return labels, [None] * 90
    if window == "24h":
        start = now - timedelta(hours=24)
        bucket_format = "%Y-%m-%d %H"
        label_format = "%I %p"
        count = 24
        step = timedelta(hours=1)
    elif window == "30d":
        start = now - timedelta(days=29)
        bucket_format = "%Y-%m-%d"
        label_format = "%d %b"
        count = 30
        step = timedelta(days=1)
    else:
        window = "7d"
        start = now - timedelta(days=6)
        bucket_format = "%Y-%m-%d"
        label_format = "%a"
        count = 7
        step = timedelta(days=1)

    with connect_db() as connection:
        rows = connection.execute(
            """
            SELECT observed_at, aqi
            FROM readings
            WHERE record_type = 'measured'
              AND aqi IS NOT NULL
              AND observed_at >= ?
            ORDER BY datetime(observed_at)
            """,
            (start.isoformat(),),
        ).fetchall()

    buckets: dict[str, list[float]] = {}
    for row in rows:
        observed_at = parse_observed_at(row["observed_at"])
        if observed_at is None:
            continue
        bucket = observed_at.strftime(bucket_format)
        buckets.setdefault(bucket, []).append(float(row["aqi"]))

    labels: list[str] = []
    values: list[float | None] = []
    local_start = start.astimezone(INDIA_TZ)
    if window == "24h":
        local_start = local_start.replace(minute=0, second=0, microsecond=0)
    else:
        local_start = local_start.replace(hour=0, minute=0, second=0, microsecond=0)
    for index in range(count):
        point = local_start + (step * index)
        bucket = point.strftime(bucket_format)
        labels.append(point.strftime(label_format))
        readings = buckets.get(bucket, [])
        values.append(round(median(readings), 1) if readings else None)
    return labels, values


@lru_cache(maxsize=8)
def fetch_open_meteo_history(start_date: str, end_date: str, window: str = "90d") -> dict:
    """Fetch hourly model AQI or calculate daily medians for the selected range."""
    parameters = urlencode({
        "latitude": "30.7333",
        "longitude": "76.7794",
        "hourly": "us_aqi",
        "start_date": start_date,
        "end_date": end_date,
        "timezone": "Asia/Kolkata",
    })
    payload = fetch_json(f"{OPEN_METEO_AIR_QUALITY_API}?{parameters}", timeout=20)
    hourly = payload.get("hourly") or {}
    times = hourly.get("time") or []
    values = hourly.get("us_aqi") or []
    if not times or len(times) != len(values):
        raise RuntimeError("Open-Meteo returned no usable hourly AQI history.")

    if window == "24h":
        points = [(timestamp, value) for timestamp, value in zip(times, values) if value is not None][-24:]
        return {
            "labels": [datetime.fromisoformat(timestamp).strftime("%I %p").lstrip("0") for timestamp, _ in points],
            "values": [round(float(value), 1) for _, value in points],
            "start_date": start_date,
            "end_date": end_date,
        }

    buckets: dict[str, list[float]] = {}
    for timestamp, value in zip(times, values):
        if value is None:
            continue
        try:
            buckets.setdefault(timestamp[:10], []).append(float(value))
        except (TypeError, ValueError):
            continue

    labels: list[str] = []
    daily_medians: list[float | None] = []
    first_day = datetime.fromisoformat(start_date).date()
    last_day = datetime.fromisoformat(end_date).date()
    current_day = first_day
    while current_day <= last_day:
        labels.append(current_day.strftime("%d %b"))
        day_values = buckets.get(current_day.isoformat(), [])
        daily_medians.append(round(median(day_values), 1) if day_values else None)
        current_day += timedelta(days=1)

    return {"labels": labels, "values": daily_medians, "start_date": start_date, "end_date": end_date}


@app.context_processor
def add_shared_template_data() -> dict:
    return {"nav_items": NAV_ITEMS}


@app.get("/")
def dashboard():
    latest = get_latest_reading()
    default_window = "7d" if latest else "90d"
    window = request.args.get("window", default_window)
    if window not in {"24h", "7d", "30d", "90d"}:
        window = default_window
    stations = get_station_summaries()
    labels, values = get_trend(window)
    return render_template(
        "dashboard.html",
        page_title="Overview",
        latest=latest,
        stations=stations,
        station_count=len(stations),
        latest_time=display_time(latest["observed_at"]) if latest else None,
        source_name=latest["source_name"] if latest else None,
        trend_labels=labels,
        trend_values=values,
        window=window,
        has_trend=any(value is not None for value in values),
        waqi_browser_token=os.environ.get("WAQI_API_TOKEN"),
    )


@app.get("/api/history/open-meteo")
def open_meteo_history():
    window = request.args.get("window", "90d")
    if window not in {"24h", "7d", "30d", "90d"}:
        return jsonify({"error": "Window must be 24h, 7d, 30d, or 90d."}), 400
    day_count = {"24h": 1, "7d": 7, "30d": 30, "90d": 90}[window]
    end_date = datetime.now(INDIA_TZ).date() - timedelta(days=1)
    start_date = end_date - timedelta(days=day_count - 1)
    try:
        history = fetch_open_meteo_history(start_date.isoformat(), end_date.isoformat(), window)
    except RuntimeError as error:
        return jsonify({"error": str(error)}), 502
    response = jsonify({
        **history,
        "source": "Open-Meteo Air Quality API",
        "attribution": "Open-Meteo · CAMS model data",
    })
    response.headers["Cache-Control"] = "public, max-age=21600"
    return response


@app.get("/map")
def air_map():
    stations = get_station_summaries()
    return render_template(
        "map.html",
        page_title="Air map",
        stations=stations,
        station_count=len(stations),
        # Personal-project fallback requested by the user when the server has no egress.
        waqi_browser_token=os.environ.get("WAQI_API_TOKEN"),
    )


@app.get("/map-data")
def map_data():
    return jsonify({"stations": get_station_summaries()})


@app.get("/api/map/waqi-stations")
def waqi_map_stations():
    """Return genuine WAQI observations with the private token held on the backend."""
    token = os.environ.get("WAQI_API_TOKEN")
    if not token:
        return jsonify({"source": "waqi", "stations": [], "error": "WAQI_API_TOKEN is not configured on the server."}), 503
    try:
        south, west, north, east = requested_bounds()
        parameters = urlencode({"latlng": f"{south:.5f},{west:.5f},{north:.5f},{east:.5f}", "token": token})
        payload = fetch_json(f"{WAQI_API}/map/bounds/?{parameters}")
        if payload.get("status") != "ok" or not isinstance(payload.get("data"), list):
            raise RuntimeError(str(payload.get("data") or "WAQI did not return station data."))
        stations = []
        for item in payload["data"]:
            try:
                latitude = float(item.get("lat"))
                longitude = float(item.get("lon"))
            except (TypeError, ValueError):
                continue
            if not (south <= latitude <= north and west <= longitude <= east):
                continue
            station = item.get("station") if isinstance(item.get("station"), dict) else {}
            stations.append({"uid": item.get("uid"), "name": station.get("name") or "Unnamed WAQI station", "latitude": latitude, "longitude": longitude, "aqi": item.get("aqi"), "station_url": station.get("url"), "source": "WAQI", "standard": "US EPA AQI"})
        used_search_fallback = False
        if not stations:
            search_parameters = urlencode({"keyword": "Chandigarh", "token": token})
            search_payload = fetch_json(f"{WAQI_API}/search/?{search_parameters}")
            if search_payload.get("status") != "ok" or not isinstance(search_payload.get("data"), list):
                raise RuntimeError(str(search_payload.get("data") or "WAQI did not return Chandigarh search results."))
            used_search_fallback = True
            for item in search_payload["data"]:
                station = item.get("station") if isinstance(item.get("station"), dict) else {}
                name = station.get("name") or "Unnamed WAQI station"
                coordinates = station.get("geo")
                if "chandigarh" not in name.casefold() or not isinstance(coordinates, list) or len(coordinates) < 2:
                    continue
                try:
                    latitude, longitude = map(float, coordinates[:2])
                except (TypeError, ValueError):
                    continue
                if not (south <= latitude <= north and west <= longitude <= east):
                    continue
                station_url = station.get("url")
                aqi = item.get("aqi")
                timestamp = (item.get("time") or {}).get("stime")
                try:
                    feed_url = f"{WAQI_API}/feed/@{item.get('uid')}/?{urlencode({'token': token})}"
                    feed_payload = fetch_json(feed_url, timeout=5)
                    feed = feed_payload.get("data")
                    if feed_payload.get("status") == "ok" and isinstance(feed, dict):
                        aqi = feed.get("aqi", aqi)
                        timestamp = (feed.get("time") or {}).get("s") or timestamp
                        measurements = feed.get("iaqi") if isinstance(feed.get("iaqi"), dict) else {}
                        item["pm25"] = (measurements.get("pm25") or {}).get("v")
                        item["pm10"] = (measurements.get("pm10") or {}).get("v")
                except RuntimeError:
                    pass
                stations.append({"uid": item.get("uid"), "name": name, "latitude": latitude, "longitude": longitude, "aqi": aqi, "pm25": item.get("pm25"), "pm10": item.get("pm10"), "timestamp": timestamp, "station_url": f"https://aqicn.org/{station_url.strip('/')}/" if isinstance(station_url, str) and station_url else None, "source": "WAQI", "standard": "US EPA AQI"})
        return jsonify({"source": "waqi", "standard": "US EPA AQI", "stations": stations, "search_fallback": used_search_fallback})
    except (ValueError, RuntimeError) as error:
        return jsonify({"source": "waqi", "stations": [], "error": f"WAQI station request failed: {error}"}), 502


@app.get("/api/map/station/<int:station_id>")
def waqi_station_detail(station_id: int):
    token = os.environ.get("WAQI_API_TOKEN")
    if not token:
        return jsonify({"error": "WAQI_API_TOKEN is not configured on the server."}), 503
    try:
        payload = fetch_json(f"{WAQI_API}/feed/@{station_id}/?{urlencode({'token': token})}")
        data = payload.get("data")
        if payload.get("status") != "ok" or not isinstance(data, dict):
            raise RuntimeError(str(data or "WAQI did not return station detail."))
        measurements = data.get("iaqi") if isinstance(data.get("iaqi"), dict) else {}
        pollutants = {key: value.get("v") for key, value in measurements.items() if isinstance(value, dict) and isinstance(value.get("v"), (int, float))}
        return jsonify({"source": "WAQI", "standard": "US EPA AQI", "name": data.get("city", {}).get("name"), "aqi": data.get("aqi"), "time": data.get("time", {}).get("s"), "pollutants": pollutants, "station_url": data.get("city", {}).get("url")})
    except RuntimeError as error:
        return jsonify({"error": f"WAQI station detail failed: {error}"}), 502


@app.get("/simulator")
def simulator():
    return render_template("simulator.html", page_title="Simulator")


@app.get("/scenarios")
def scenarios():
    return render_template("scenarios.html", page_title="Compare scenarios")


@app.get("/sources")
def sources():
    with connect_db() as connection:
        data_sources = [
            dict(row)
            for row in connection.execute(
                "SELECT * FROM data_sources ORDER BY name COLLATE NOCASE"
            ).fetchall()
        ]
    return render_template(
        "sources.html",
        page_title="Data sources",
        data_sources=data_sources,
    )


@app.get("/healthz")
def healthz():
    return jsonify({"status": "ok", "application": "AIRPOCALYPSE: Chandigarh Edition"})


initialize_database()

if __name__ == "__main__":
    app.run(
        host="0.0.0.0",
        port=int(os.environ.get("PORT", "8000")),
        debug=False,
    )
