(() => {
  const element = document.getElementById("air-map");
  if (!element) return;
  const $ = (id) => document.getElementById(id);
  const escapeHtml = (value) => String(value ?? "").replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]);
  const number = (value) => Number.isFinite(Number(value)) ? Number(value) : null;
  const usColour = (value) => value == null ? "#7b8790" : value <= 50 ? "#00a65a" : value <= 100 ? "#ffde33" : value <= 150 ? "#ff9933" : value <= 200 ? "#cc0033" : value <= 300 ? "#8f3f97" : "#7e0023";
  const indiaColour = (value) => value == null ? "#7b8790" : value <= 50 ? "#00e400" : value <= 100 ? "#92d050" : value <= 200 ? "#ffff00" : value <= 300 ? "#ff7e00" : value <= 400 ? "#ff0000" : value <= 500 ? "#8f3f97" : "#7e0023";
  const json = async (response) => { const text = await response.text(); try { return JSON.parse(text); } catch { throw Error(`The data service returned HTTP ${response.status}, not JSON.`); } };
  const tokenNode = document.getElementById("waqi-browser-token");
  let browserWaqiToken = null;
  try { browserWaqiToken = tokenNode ? JSON.parse(tokenNode.textContent || "null") : null; } catch { /* backend proxy remains available */ }

  const init = () => {
    if (!window.L || element.dataset.mapReady) return;
    element.dataset.mapReady = "true";
    const map = L.map(element).setView([30.7333, 76.7794], 12);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 19, attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors' }).addTo(map);
    const overlay = L.tileLayer("https://tiles.waqi.info/tiles/usepa-aqi/{z}/{x}/{y}.png?token=demo", { opacity: .58, maxZoom: 18, attribution: 'AQI overlay &copy; <a href="https://aqicn.org/">WAQI</a> (US EPA AQI)', crossOrigin: true }).addTo(map);
    const observations = L.layerGroup().addTo(map);
    let moveTimer;
    const setText = (id, value) => { if ($(id)) $(id).textContent = value; };
    const notice = (value, isError = false) => { const target = $("map-notice"); if (!target) return; target.classList.toggle("map-notice-error", isError); target.innerHTML = `<span class="note-mark">${isError ? "!" : "i"}</span><span>${escapeHtml(value)}</span>`; };
    const setList = (stations, source, standard) => {
      const target = $("live-station-list"); if (!target) return;
      if (!stations.length) { target.innerHTML = `<div class="station-list-empty"><span class="empty-list-dash">—</span><p>${source === "model" ? "One city model estimate is displayed on the map. It is not a monitoring station." : "No verified station observations were returned by this source."}</p></div>`; return; }
      target.innerHTML = stations.map((station) => `<article class="station-row"><span class="station-marker" style="background:${source === "cpcb" ? indiaColour(number(station.aqi)) : usColour(number(station.aqi))}"></span><div class="station-row-main"><strong>${escapeHtml(station.name)}</strong><div class="station-readings"><span>${escapeHtml(standard)} <b>${station.aqi == null ? "Unavailable" : escapeHtml(station.aqi)}</b></span></div><small>${escapeHtml(station.timestamp || station.source || "Timestamp unavailable")}</small></div></article>`).join("");
    };
    const marker = (station, source, standard) => {
      const colour = source === "cpcb" ? indiaColour(number(station.aqi)) : usColour(number(station.aqi));
      const pollutants = Object.entries(station.pollutants || {}).map(([name, entry]) => { const value = typeof entry === "object" ? entry.value : entry; const unit = typeof entry === "object" && entry.unit ? ` ${entry.unit}` : ""; return `<span>${escapeHtml(name.toUpperCase())} <b>${escapeHtml(value)}${escapeHtml(unit)}</b></span>`; }).join("");
      const link = station.station_url ? `<a class="station-source-link" href="${escapeHtml(station.station_url)}" target="_blank" rel="noopener">View source station page ↗</a>` : "";
      L.marker([station.latitude, station.longitude], { icon: L.divIcon({ className: "air-marker", html: `<span style="--aqi-colour:${colour}"></span>`, iconSize: [18, 18], iconAnchor: [9, 9] }), title: station.name }).addTo(observations).bindPopup(`<div class="map-popup-title">${escapeHtml(station.name)}</div><div class="map-popup-subtitle">${escapeHtml(station.source || source.toUpperCase())} · ${escapeHtml(standard)}</div><div class="map-popup-values"><span>AQI <b>${station.aqi == null ? "Unavailable" : escapeHtml(station.aqi)}</b></span></div><div class="map-popup-values map-popup-pollutants">${pollutants || "<span>No pollutant measurements supplied</span>"}</div><div class="map-popup-time">Observed: ${escapeHtml(station.timestamp || "Timestamp unavailable")}</div>${link}`);
    };
    const directWaqi = async (params) => {
      if (!browserWaqiToken) throw Error("WAQI token is not available for the direct browser fallback.");
      const query = new URLSearchParams(params); query.set("latlng", `${query.get("south")},${query.get("west")},${query.get("north")},${query.get("east")}`); query.delete("south"); query.delete("west"); query.delete("north"); query.delete("east"); query.set("token", browserWaqiToken);
      const response = await fetch(`https://api.waqi.info/map/bounds/?${query}`, { signal: AbortSignal.timeout(12000) });
      const payload = await json(response);
      if (!response.ok || payload.status !== "ok" || !Array.isArray(payload.data)) throw Error(typeof payload.data === "string" ? `WAQI direct request failed: ${payload.data}` : "WAQI did not return station data.");
      const stations = payload.data.filter((item) => Number.isFinite(Number(item.lat)) && Number.isFinite(Number(item.lon))).map((item) => ({ uid: item.uid, name: item.station?.name || "Unnamed WAQI station", latitude: Number(item.lat), longitude: Number(item.lon), aqi: item.aqi, station_url: item.station?.url, source: "WAQI", standard: "US EPA AQI" }));
      if (stations.length) return { source: "waqi", standard: "US EPA AQI", direct: true, stations };

      const searchQuery = new URLSearchParams({ keyword: "Chandigarh", token: browserWaqiToken });
      const searchResponse = await fetch(`https://api.waqi.info/search/?${searchQuery}`, { signal: AbortSignal.timeout(12000) });
      const searchPayload = await json(searchResponse);
      if (!searchResponse.ok || searchPayload.status !== "ok" || !Array.isArray(searchPayload.data)) throw Error("WAQI did not return Chandigarh search results.");
      const bounds = Object.fromEntries(["south", "west", "north", "east"].map((key) => [key, Number(params.get(key))]));
      const searchedStations = searchPayload.data.flatMap((item) => {
        const station = item.station || {};
        const [latitude, longitude] = (station.geo || []).map(Number);
        const name = station.name || "Unnamed WAQI station";
        if (!name.toLowerCase().includes("chandigarh") || !Number.isFinite(latitude) || !Number.isFinite(longitude) || latitude < bounds.south || latitude > bounds.north || longitude < bounds.west || longitude > bounds.east) return [];
        return [{ uid: item.uid, name, latitude, longitude, aqi: item.aqi, timestamp: item.time?.stime, station_url: station.url ? `https://aqicn.org/${station.url.replace(/^\/+|\/+$/g, "")}/` : null, source: "WAQI", standard: "US EPA AQI" }];
      });
      const stationsWithReadings = await Promise.all(searchedStations.map(async (station) => {
        if (Number.isFinite(Number(station.aqi))) return station;
        try {
          const feedQuery = new URLSearchParams({ token: browserWaqiToken });
          const feedResponse = await fetch(`https://api.waqi.info/feed/@${station.uid}/?${feedQuery}`, { signal: AbortSignal.timeout(10000) });
          const feedPayload = await json(feedResponse);
          if (!feedResponse.ok || feedPayload.status !== "ok" || !feedPayload.data) return station;
          return {
            ...station,
            aqi: feedPayload.data.aqi ?? station.aqi,
            timestamp: feedPayload.data.time?.s || station.timestamp,
          };
        } catch {
          return station;
        }
      }));
      return { source: "waqi", standard: "US EPA AQI", direct: true, search_fallback: true, stations: stationsWithReadings };
    };
    const renderModel = async () => {
      const estimate = await window.fetchOpenMeteoEstimate();
      const station = { name: "Chandigarh city model estimate", latitude: estimate.latitude, longitude: estimate.longitude, aqi: estimate.aqi, timestamp: estimate.timestamp, source: "Open-Meteo model", pollutants: { pm2_5: { value: estimate.pm25, unit: "μg/m³" }, pm10: { value: estimate.pm10, unit: "μg/m³" } } };
      marker(station, "model", "US EPA AQI model"); setText("map-source-state", "OPEN-METEO MODEL ESTIMATE"); setText("station-count", "1 city model estimate"); setList([], "model", "US EPA AQI"); notice("This is a modelled city estimate, not CPCB monitoring-station data. Choose Official CPCB for measured Indian National AQI.");
    };
    const refresh = async () => {
      observations.clearLayers();
      const source = $("map-source")?.value || "cpcb";
      setText("map-source-state", "LOADING DATA"); setText("station-count", "Loading…");
      try {
        if (source === "model") { await renderModel(); return; }
        const bounds = map.getBounds();
        const params = new URLSearchParams({ south: bounds.getSouth(), west: bounds.getWest(), north: bounds.getNorth(), east: bounds.getEast() });
        const url = source === "cpcb" ? "/api/map/cpcb-stations" : `/api/map/waqi-stations?${params}`;
        let data;
        try { const response = await fetch(url, { signal: AbortSignal.timeout(12000) }); data = await json(response); if (!response.ok) throw Error(data.error || "The selected source could not provide station data."); }
        catch (serverError) { if (source !== "waqi") throw serverError; data = await directWaqi(params); }
        const stations = Array.isArray(data.stations) ? data.stations : [];
        const standard = data.standard || (source === "cpcb" ? "Indian CPCB National AQI" : "US EPA AQI");
        stations.forEach((station) => marker(station, source, standard)); setList(stations, source, standard);
        setText("map-source-state", source === "cpcb" ? "OFFICIAL CPCB STATIONS" : "WAQI STATION OBSERVATIONS"); setText("station-count", `${stations.length} station${stations.length === 1 ? "" : "s"}`);
        notice(stations.length ? `${data.direct ? "WAQI was loaded directly in this personal project because the local server cannot reach it. " : ""}${data.search_fallback ? "WAQI bounds were empty, so Chandigarh city-search results are shown. " : ""}${source === "cpcb" ? "Measured CPCB observations using Indian National AQI." : "WAQI observations using US EPA AQI; these are not Indian CPCB AQI values."}` : `The selected ${source === "cpcb" ? "official CPCB" : "WAQI"} source returned no Chandigarh stations.`);
      } catch (error) { setList([], source, ""); setText("map-source-state", `${source.toUpperCase()} UNAVAILABLE`); setText("station-count", "No live station data"); notice(error.message, true); }
      finally { setText("map-last-updated", `Checked ${new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`); }
    };
    $("map-source")?.addEventListener("change", refresh);
    $("refresh-map")?.addEventListener("click", refresh);
    $("toggle-aqi")?.addEventListener("click", (event) => { const visible = map.hasLayer(overlay); visible ? map.removeLayer(overlay) : overlay.addTo(map); event.currentTarget.textContent = `AQI overlay: ${visible ? "off" : "on"}`; event.currentTarget.setAttribute("aria-pressed", String(!visible)); });
    $("toggle-stations")?.addEventListener("click", (event) => { const visible = map.hasLayer(observations); visible ? map.removeLayer(observations) : observations.addTo(map); event.currentTarget.textContent = `Stations: ${visible ? "off" : "on"}`; event.currentTarget.setAttribute("aria-pressed", String(!visible)); });
    map.on("moveend", () => { if (($("map-source")?.value || "cpcb") === "model") return; clearTimeout(moveTimer); moveTimer = setTimeout(refresh, 800); });
    new ResizeObserver(() => map.invalidateSize()).observe(element); refresh();
  };
  if (window.L) init(); else document.querySelector('script[src*="leaflet.js"]')?.addEventListener("load", init, { once: true });
})();
