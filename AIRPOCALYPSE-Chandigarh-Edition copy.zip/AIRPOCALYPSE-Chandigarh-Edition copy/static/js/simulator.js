(() => {
  const sliders = [
    ["traffic", "traffic-value"],
    ["dust", "dust-value"],
    ["green", "green-value"],
  ];

  sliders.forEach(([inputId, outputId]) => {
    const input = document.getElementById(inputId);
    const output = document.getElementById(outputId);
    if (!input || !output) return;
    input.addEventListener("input", () => {
      output.value = `${input.value}%`;
      output.textContent = `${input.value}%`;
    });
  });

  const form = document.getElementById("scenario-form");
  const feedback = document.getElementById("scenario-feedback");
  if (!form || !feedback) return;
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    feedback.hidden = false;
    feedback.textContent = "Inputs are for interface preview only. The scenario calculation engine is not active, so no AQI outcome was generated or saved.";
  });
})();
