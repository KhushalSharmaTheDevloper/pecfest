(() => {
  const date = document.getElementById("local-date");
  if (date) {
    const now = new Intl.DateTimeFormat("en-IN", {
      timeZone: "Asia/Kolkata",
      weekday: "short",
      day: "2-digit",
      month: "short",
      hour: "2-digit",
      minute: "2-digit",
      hour12: false,
    }).format(new Date());
    date.textContent = `${now} IST`;
  }
})();
