import unittest
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from app import app

class AQIInProjectTests(unittest.TestCase):
    def setUp(self):
        self.client = app.test_client()
    def test_overview_uses_aqi_in_default(self):
        response = self.client.get('/overview?window=24h')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'AQI.IN SCRAPE READY', response.data)
        self.assertNotIn(b'id="overview-source"', response.data)
        self.assertNotIn(b'Measured reading</option>', response.data)
    def test_map_uses_aqi_in_default(self):
        response = self.client.get('/air-map')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'AQI.IN (US EPA AQI)', response.data)
    def test_simulator_uses_aqi_in_endpoint(self):
        response = self.client.get('/simulator')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'simulator.js', response.data)
        script_response = self.client.get('/static/js/simulator.js')
        self.assertEqual(script_response.status_code, 200)
        self.assertIn(b'/api/aqiin/chandigarh', script_response.data)
    def test_sources_include_aqi_in(self):
        response = self.client.get('/sources')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'AQI.IN', response.data)
    def test_hourly_trend_has_24_buckets(self):
        response = self.client.get('/api/aqi/trend/24h')
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        self.assertEqual(len(data['labels']), 24)
        self.assertEqual(len(data['values']), 24)

    def test_daily_trend_windows_have_requested_buckets(self):
        for window, count in (("7d", 7), ("30d", 30), ("90d", 90)):
            response = self.client.get(f'/api/aqi/trend/{window}')
            self.assertEqual(response.status_code, 200)
            data = response.get_json()
            self.assertEqual(len(data['labels']), count)
            self.assertEqual(len(data['values']), count)

    def test_daily_trends_end_yesterday(self):
        yesterday = datetime.now(ZoneInfo('Asia/Kolkata')).date() - timedelta(days=1)
        for window in ('7d', '30d', '90d'):
            response = self.client.get(f'/api/aqi/trend/{window}')
            self.assertEqual(response.status_code, 200)
            labels = response.get_json()['labels']
            parsed = datetime.strptime(f"{labels[-1]} {yesterday.year}", '%d %b %Y').date()
            self.assertEqual(parsed, yesterday)


if __name__ == '__main__':
    unittest.main()
