(() => {
  const AQIIN_REFRESH_INTERVAL_MS = 10 * 60 * 1000;
  const form = document.getElementById("scenario-form");
  if (!form) return;

  const pm25Input = document.getElementById("baseline-pm25");
  const pm10Input = document.getElementById("baseline-pm10");
  const growthInput = document.getElementById("annual-growth");
  const feedback = document.getElementById("scenario-feedback");
  const baselineStatus = document.getElementById("baseline-status");
  const sourceLabel = document.getElementById("scenario-source");
  const controls = ["vehicular_transport", "industry", "biomass_waste", "road_dust", "secondary_particles"];
  const sliders = controls;
  const sourceShares = {
    vehicular_transport: [0.20, 0.35],
    industry: [0.15, 0.30],
    biomass_waste: [0.15, 0.25],
    road_dust: [0.10, 0.20],
    secondary_particles: [0.15, 0.25],
  };
  let baselineSource = "AQI.IN Chandigarh pollutant readings";
  let aqiInBaselineAqi = null;
  let baselineEdited = false;
  let baselineLoading = false;
  const setText = (id, value) => {
    const element = document.getElementById(id);
    if (element) element.textContent = value;
  };
  const setPageLoading = (isLoading) => {
    const page = document.querySelector(".page-container");
    if (!page) return;
    page.classList.toggle("is-data-loading", isLoading);
    page.setAttribute("aria-busy", String(isLoading));
  };
  const airQuality = (aqi) => {
    if (aqi <= 50) return { label: "Balanced", condition: "balanced" };
    if (aqi <= 150) return { label: "Moderate", condition: "moderate" };
    return { label: "Poor", condition: "poor" };
  };
  const updateAirScene = (aqi, levels, baselineAqi) => {
    const scene = document.getElementById("air-scene");
    const graphic = document.getElementById("air-scene-graphic");
    const meter = document.getElementById("air-quality-meter");
    const status = airQuality(aqi);
    const averageVehicularControls = levels.vehicular_transport;
    scene.dataset.condition = status.condition;
    setText("air-scene-status", `${status.label} air`);
    meter.setAttribute("aria-valuenow", String(Math.min(500, aqi)));
    meter.setAttribute("aria-valuetext", `Scenario AQI ${aqi}; ${status.label}`);
    document.getElementById("air-quality-baseline-marker").style.left = `${Math.min(100, baselineAqi / 500 * 100)}%`;
    document.getElementById("air-quality-scenario-marker").style.left = `${Math.min(100, aqi / 500 * 100)}%`;
    graphic.style.setProperty("--smog-opacity", String(0.12 + Math.min(aqi, 500) / 500 * 0.72));
    graphic.style.setProperty("--traffic-opacity", String(Math.max(0.12, 1 - averageVehicularControls / 100 * 0.88)));
    graphic.style.setProperty("--green-opacity", "0.6");
  };
  const setAirQuality = (aqi) => {
    const quality = airQuality(aqi);
    document.getElementById("air-scene").dataset.condition = quality.condition;
    setText("scenario-stage", quality.label);
    setText("scenario-stage-detail", `Estimated scenario AQI ${aqi} · ${quality.label} air.`);
  };
  const grapLevel = (aqi) => {
    if (aqi <= 200) return "Below Level 1";
    if (aqi <= 300) return "Level 1";
    if (aqi <= 400) return "Level 2";
    if (aqi <= 450) return "Level 3";
    return "Level 4";
  };
  const projectionCategory = (aqi) => {
    if (aqi <= 50) return "Good";
    if (aqi <= 100) return "Moderate";
    if (aqi <= 150) return "Moderate-Poor";
    if (aqi <= 200) return "Unhealthy";
    if (aqi <= 300) return "Very Unhealthy";
    return "Hazardous";
  };
  const updateGrapMeter = (aqi) => {
    const meter = document.getElementById("grap-meter");
    const marker = document.getElementById("grap-meter-marker");
    const level = grapLevel(aqi);
    meter.setAttribute("aria-valuenow", String(Math.min(500, aqi)));
    meter.setAttribute("aria-valuetext", `Scenario AQI ${aqi}; ${level}, hypothetical reference only`);
    marker.style.left = `${Math.min(100, (aqi / 500) * 100)}%`;
    setText("grap-meter-label", `${level} · AQI ${aqi}`);
  };
  const updateProjection = (scenarioAqi) => {
    const annualGrowth = readNumber(growthInput);
    const list = document.getElementById("projection-years");
    list.replaceChildren();
    if (!Number.isFinite(scenarioAqi)) {
      setText("projection-disclaimer", "Enter valid baseline readings to calculate the illustrative current-controls scenario.");
      return;
    }
    if (annualGrowth === null || annualGrowth < 0 || annualGrowth > 25) {
      setText("projection-disclaimer", "Enter an annual AQI increase between 0% and 25% to calculate this illustrative current-controls scenario.");
      return;
    }
    setText("projection-disclaimer", `Illustrative scenario, not a forecast: starting scenario AQI ${scenarioAqi} after current controls, with ${format(annualGrowth)}% assumed annual increase compounded. Current control settings are assumed to remain in place.`);
    for (let year = 1; year <= 5; year += 1) {
      const growthFactor = (1 + annualGrowth / 100) ** year;
      const projectedAqi = Math.round(scenarioAqi * growthFactor);
      const item = document.createElement("li");
      item.className = "projection-year";
      const label = document.createElement("span");
      label.textContent = `Year ${year}`;
      const bar = document.createElement("span");
      bar.className = "projection-bar";
      bar.setAttribute("aria-hidden", "true");
      const fill = document.createElement("span");
      fill.className = "projection-bar-fill";
      fill.style.width = `${Math.min(100, (projectedAqi / 500) * 100)}%`;
      bar.append(fill);
      const result = document.createElement("strong");
      result.textContent = `${projectedAqi} · ${projectionCategory(projectedAqi)}`;
      item.append(label, bar, result);
      list.append(item);
    }
  };
  const setUnavailable = () => {
    const scene = document.getElementById("air-scene");
    scene.dataset.condition = "unknown";
    setText("baseline-aqi", "—");
    setText("scenario-aqi", "—");
    setText("scenario-pm25", "—");
    setText("scenario-pm10", "—");
    setText("scenario-impact", "Enter valid baseline readings to preview the scenario.");
    setText("scenario-stage", "—");
    setText("scenario-stage-detail", "Enter valid baseline readings to calculate the air-quality label.");
    setText("air-scene-status", "Waiting…");
    document.getElementById("air-scene-graphic").style.setProperty("--smog-opacity", "0.5");
    document.getElementById("air-scene-graphic").style.setProperty("--traffic-opacity", "1");
    document.getElementById("air-scene-graphic").style.setProperty("--green-opacity", "0.6");
    const meter = document.getElementById("air-quality-meter");
    meter.setAttribute("aria-valuenow", "0");
    meter.setAttribute("aria-valuetext", "Enter valid baseline readings");
    document.getElementById("air-quality-baseline-marker").style.left = "0%";
    document.getElementById("air-quality-scenario-marker").style.left = "0%";
    setText("grap-meter-label", "—");
    document.getElementById("grap-meter").setAttribute("aria-valuenow", "0");
    document.getElementById("grap-meter").setAttribute("aria-valuetext", "Enter valid baseline readings");
    document.getElementById("grap-meter-marker").style.left = "0%";
    document.getElementById("projection-years").replaceChildren();
    setText("projection-disclaimer", "Enter valid baseline readings to calculate the illustrative current-controls scenario.");
  };
  const showError = (message) => {
    feedback.hidden = false;
    feedback.textContent = message;
  };
  const readNumber = (input) => {
    const value = Number(input.value);
    return input.value.trim() !== "" && Number.isFinite(value) ? value : null;
  };
  const format = (value) => Number(value).toFixed(1);
  const particulateAqi = (concentration, pollutant) => {
    const breakpoints = pollutant === "pm25"
      ? [[0, 9, 0, 50], [9.1, 35.4, 51, 100], [35.5, 55.4, 101, 150], [55.5, 125.4, 151, 200], [125.5, 225.4, 201, 300], [225.5, 325.4, 301, 500]]
      : [[0, 54, 0, 50], [55, 154, 51, 100], [155, 254, 101, 150], [255, 354, 151, 200], [355, 424, 201, 300], [425, 604, 301, 500]];
    const rounded = pollutant === "pm25" ? Math.floor(Math.max(0, concentration) * 10) / 10 : Math.floor(Math.max(0, concentration));
    const range = breakpoints.find(([low, high]) => rounded >= low && rounded <= high);
    if (!range) return 500;
    const [low, high, indexLow, indexHigh] = range;
    return Math.round((indexHigh - indexLow) / (high - low) * (rounded - low) + indexLow);
  };
  const getScenarioRange = (concentration, pollutant, levels = null) => {
    let reductionLow = 0;
    let reductionHigh = 0;
    for (const control of controls) {
      const shareLow = sourceShares[control][0];
      const shareHigh = sourceShares[control][1];
      const controlTaken = (levels ? levels[control] : Number(document.getElementById(control).value)) / 100;
      reductionLow += controlTaken * shareLow;
      reductionHigh += controlTaken * shareHigh;
    }
    reductionLow = Math.min(1, reductionLow);
    reductionHigh = Math.min(1, reductionHigh);
    return {
      low: concentration * (1 - reductionHigh),
      high: concentration * (1 - reductionLow),
      reductionLow,
      reductionHigh,
    };
  };
  const getScenarioAqiRange = (pm25, pm10, levels) => {
    const baselineAqi = !baselineEdited && aqiInBaselineAqi !== null
      ? aqiInBaselineAqi
      : Math.max(particulateAqi(pm25, "pm25"), particulateAqi(pm10, "pm10"));
    let reductionLow = 0;
    let reductionHigh = 0;
    for (const control of controls) {
      const controlTaken = levels[control] / 100;
      reductionLow += controlTaken * sourceShares[control][0];
      reductionHigh += controlTaken * sourceShares[control][1];
    }
    reductionLow = Math.min(1, reductionLow);
    reductionHigh = Math.min(1, reductionHigh);
    const allFiveFullyControlled = controls.every((control) => levels[control] === 100);
    if (allFiveFullyControlled) return { low: 40, high: 60 };
    const naturalFloor = 50;
    const adjustableAqi = Math.max(0, baselineAqi - naturalFloor);
    if (adjustableAqi <= 0 || baselineAqi <= 40) return { low: baselineAqi, high: baselineAqi };
    const low = Number(Math.min(baselineAqi, Math.max(40, baselineAqi - adjustableAqi * reductionHigh)).toFixed(1));
    const high = Number(Math.min(baselineAqi, Math.max(40, baselineAqi - adjustableAqi * reductionLow)).toFixed(1));
    return { low: Math.min(low, high), high: Math.max(low, high) };
  };
  const recommendControls = (pm25, pm10, currentLevels, scenarioHigh) => {
    const maximumLevels = Object.fromEntries(controls.map((name) => [name, 100]));
    const maximum = getScenarioAqiRange(pm25, pm10, maximumLevels).high;
    return "At 100% implementation of all five factors, the screening estimate reaches the natural base range of AQI 40–60, the residual with no direct human activity.";
  };
  const calculate = () => {
    const pm25 = readNumber(pm25Input);
    const pm10 = readNumber(pm10Input);
    if (pm25 === null || pm10 === null) {
      setText("baseline-aqi", "—");
      setText("scenario-aqi", "—");
      setText("scenario-pm25", "—");
      setText("scenario-pm10", "—");
      setText("baseline-pm25-result", "Baseline — µg/m³");
      setText("baseline-pm10-result", "Baseline — µg/m³");
      setUnavailable();
      showError("Enter PM₂.₅ and PM₁₀ values between 0 and 1000 µg/m³.");
      return;
    }
    if (pm25 < 0 || pm25 > 1000 || pm10 < 0 || pm10 > 1000) {
      setUnavailable();
      showError("Baseline particulate values must be between 0 and 1000 µg/m³.");
      return;
    }

    feedback.hidden = true;
    const particulateBaselineAqi = Math.max(particulateAqi(pm25, "pm25"), particulateAqi(pm10, "pm10"));
    const baselineAqi = !baselineEdited && aqiInBaselineAqi !== null
      ? aqiInBaselineAqi
      : particulateBaselineAqi;
    const currentLevels = Object.fromEntries(controls.map((name) => [
      name,
      Number(document.getElementById(name).value),
    ]));

    const pm25Range = getScenarioRange(pm25, "pm25", currentLevels);
    const pm10Range = getScenarioRange(pm10, "pm10", currentLevels);
    const scenarioAqiRange = getScenarioAqiRange(pm25, pm10, currentLevels);
    const allControlsFullyApplied = controls.every((control) => currentLevels[control] === 100);
    const scenarioAqi = Math.round((scenarioAqiRange.low + scenarioAqiRange.high) / 2);
    const scenarioAqiText = allControlsFullyApplied
      ? `${Math.round(scenarioAqiRange.low)}–${Math.round(scenarioAqiRange.high)}`
      : String(scenarioAqi);
    setText("baseline-aqi", String(baselineAqi));
    setText("scenario-aqi", scenarioAqiText);
    setAirQuality(scenarioAqi);
    updateAirScene(scenarioAqi, currentLevels, baselineAqi);
    updateGrapMeter(scenarioAqi);
    updateProjection(scenarioAqi);
    setText("scenario-pm25", `${format(pm25Range.low)}–${format(pm25Range.high)}`);
    setText("scenario-pm10", `${format(pm10Range.low)}–${format(pm10Range.high)}`);
    setText("baseline-pm25-result", `Baseline ${format(pm25)} µg/m³`);
    setText("baseline-pm10-result", `Baseline ${format(pm10)} µg/m³`);
    const reductionLow = Math.min(
      pm25 > 0 ? 1 - pm25Range.high / pm25 : 0,
      pm10 > 0 ? 1 - pm10Range.high / pm10 : 0,
    ) * 100;
    const reductionHigh = Math.max(
      pm25 > 0 ? 1 - pm25Range.low / pm25 : 0,
      pm10 > 0 ? 1 - pm10Range.low / pm10 : 0,
    ) * 100;
    const aqiReductionLow = Math.max(0, (1 - scenarioAqiRange.high / baselineAqi) * 100);
    const aqiReductionHigh = Math.max(0, (1 - scenarioAqiRange.low / baselineAqi) * 100);
    setText("scenario-impact", `Illustrative AQI reduction: ${format(Math.min(aqiReductionLow, aqiReductionHigh))}–${format(Math.max(aqiReductionLow, aqiReductionHigh))}%`);
    sourceLabel.textContent = `Baseline source: ${baselineEdited ? "manual values" : baselineSource}. Scenario output is illustrative, not a forecast.`;
  };

  sliders.forEach((name) => {
    const input = document.getElementById(name);
    const output = document.getElementById(`${name}-value`);
    input.addEventListener("input", () => {
      output.value = input.value;
      calculate();
    });
    output.addEventListener("input", () => {
      if (output.value === "") return;
      const level = Math.min(100, Math.max(0, Math.round(Number(output.value))));
      input.value = String(level);
      calculate();
    });
    output.addEventListener("change", () => {
      if (output.value === "" || !Number.isFinite(Number(output.value))) output.value = input.value;
      else output.value = String(Math.min(100, Math.max(0, Math.round(Number(output.value)))));
      input.value = output.value;
      calculate();
    });
  });

  const presetReset = document.getElementById("preset-reset");
  const setControlLevels = (levels) => {
    sliders.forEach((name) => {
      const input = document.getElementById(name);
      const output = document.getElementById(`${name}-value`);
      const level = levels[name] ?? 0;
      input.value = String(level);
      output.value = String(level);
    });
    calculate();
  };
  if (presetReset) presetReset.addEventListener("click", () => setControlLevels({}));

  const presets = {
    "traffic-dust": { vehicular_transport: 100, road_dust: 100 },
    industry: { industry: 100 },
    burning: { biomass_waste: 100 },
  };
  document.querySelectorAll("[data-preset]").forEach((button) => {
    button.addEventListener("click", () => {
      const preset = presets[button.dataset.preset];
      if (preset) setControlLevels(preset);
    });
  });

  [pm25Input, pm10Input].forEach((input) => {
    input.addEventListener("input", () => {
      baselineEdited = true;
      aqiInBaselineAqi = null;
      setPageLoading(false);
      baselineStatus.textContent = "Using your manually entered baseline values.";
      sourceLabel.textContent = "Baseline source: manually entered particulate values.";
      calculate();
    });
  });

  growthInput.addEventListener("input", calculate);

  form.addEventListener("submit", (event) => event.preventDefault());

  const measurement = (value) => value !== null && value !== undefined && value !== "" && Number.isFinite(Number(value)) ? Number(value) : null;
  const pm25FromAqi = (aqi) => {
    const ranges = [[0, 50, 0, 12], [51, 100, 12.1, 35.4], [101, 150, 35.5, 55.4], [151, 200, 55.5, 150.4], [201, 300, 150.5, 250.4], [301, 500, 250.5, 500.4]];
    const value = Number(aqi);
    if (!Number.isFinite(value)) return null;
    const range = ranges.find(([low, high]) => value >= low && value <= high);
    if (!range) return null;
    const [lowAqi, highAqi, lowPm, highPm] = range;
    return Math.round((lowPm + (value - lowAqi) / (highAqi - lowAqi) * (highPm - lowPm)) * 10) / 10;
  };
  const loadBaseline = async () => {
    if (baselineEdited || baselineLoading) return;
    baselineLoading = true;
    setPageLoading(true);
    try {
      const response = await fetch("/api/aqiin/chandigarh", { signal: AbortSignal.timeout(15000) });
      const aqiReading = await response.json();
      if (!response.ok || !Number.isFinite(Number(aqiReading.aqi))) {
        throw Error(aqiReading.error || "AQI.IN returned no usable reading.");
      }

      aqiInBaselineAqi = Math.round(Number(aqiReading.aqi));
      const pm25 = measurement(aqiReading.pm25) ?? pm25FromAqi(aqiReading.aqi);
      const pm10 = measurement(aqiReading.pm10) ?? (pm25 === null ? null : Math.round(pm25 * 1.2 * 10) / 10);
      if (pm25 === null || pm10 === null) throw Error("AQI.IN returned no numeric particulate readings.");

      baselineSource = "AQI.IN Chandigarh pollutant readings";
      if (!baselineEdited) {
        pm25Input.value = pm25;
        pm10Input.value = pm10;
        baselineStatus.textContent = `Loaded AQI ${aqiInBaselineAqi} and matching particulate values from AQI.IN Chandigarh. The baseline AQI uses the exact AQI.IN reading.`;
        sourceLabel.textContent = `Baseline source: AQI.IN Chandigarh (AQI ${aqiInBaselineAqi}).`;
        calculate();
      }
    } catch (error) {
      aqiInBaselineAqi = null;
      baselineStatus.textContent = `Could not load the AQI.IN default baseline: ${error.message || "provider unavailable"}. Enter PM₂.₅ and PM₁₀ values manually to continue.`;
    } finally {
      baselineLoading = false;
      setPageLoading(false);
    }
  };

  loadBaseline();
  window.setInterval(() => {
    if (!document.hidden) loadBaseline();
  }, AQIIN_REFRESH_INTERVAL_MS);
})();
