﻿(() => {
  const element = document.getElementById("air-map");
  if (!element || !window.L) return;
  const setText = (id, value) => { const node = document.getElementById(id); if (node) node.textContent = value; };
  const escapeHtml = (value) => String(value ?? "").replace(/[&<>"']/g, (char) => ({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"})[char]);
  const cityBounds = L.latLngBounds([[30.65, 76.70], [30.81, 76.85]]);
  const map = L.map(element, { maxBounds: cityBounds, maxBoundsViscosity: 1 }).setView([30.7333, 76.7794], 12);
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 19, attribution: "&copy; OpenStreetMap contributors" }).addTo(map);
  const fit = () => { map.invalidateSize(); const minZoom = map.getBoundsZoom(cityBounds, false, L.point(16, 16)); map.setMinZoom(minZoom); if (map.getZoom() < minZoom) map.fitBounds(cityBounds, { padding: [16, 16] }); map.panInsideBounds(cityBounds, { animate: false }); };
  fit();
  let observations;
  const colour = (aqi) => aqi == null ? "#7b8790" : aqi <= 50 ? "#00a65a" : aqi <= 100 ? "#ffde33" : aqi <= 150 ? "#ff9933" : aqi <= 200 ? "#cc0033" : aqi <= 300 ? "#8f3f97" : "#7e0023";
  const loadAqiIn = async () => {
    const refresh = document.getElementById("refresh-map"); if (refresh) refresh.disabled = true;
    setText("map-source-state", "CONNECTING AQI.IN");
    try {
      const response = await fetch("/api/aqiin/chandigarh", { cache: "no-store", signal: AbortSignal.timeout(20000), headers: { Accept: "application/json" } });
      const data = await response.json();
      if (!response.ok || !Number.isFinite(Number(data.aqi))) throw new Error(data.error || "AQI.IN returned no usable reading");
      if (observations) observations.clearLayers(); else observations = L.layerGroup().addTo(map);
      const aqi = Math.round(Number(data.aqi));
      const icon = L.divIcon({ className: "air-marker", html: `<span style="--aqi-colour:${colour(aqi)}"></span>`, iconSize: [18, 18], iconAnchor: [9, 9] });
      const marker = L.marker([30.7333, 76.7794], { icon, title: "Chandigarh AQI.IN" }).addTo(observations);
      marker.bindPopup(`<div class="map-popup-title">Chandigarh AQI.IN</div><div class="map-popup-subtitle">AQI.IN · US EPA AQI</div><div class="map-popup-values"><span>AQI <b>${aqi}</b></span></div><div class="map-popup-values"><span>PM2.5 <b>${data.pm25 == null ? "Unavailable" : escapeHtml(data.pm25)}</b></span><span>PM10 <b>${data.pm10 == null ? "Unavailable" : escapeHtml(data.pm10)}</b></span></div><div class="map-popup-time">Observed: ${escapeHtml(data.time || "Recent AQI.IN scrape")}</div>`);
      const list = document.getElementById("live-station-list");
      if (list) list.innerHTML = `<article class="station-row"><span class="station-marker" style="background:${colour(aqi)}"></span><div class="station-row-main"><strong>Chandigarh</strong><div class="station-readings"><span>US EPA AQI <b>${aqi}</b></span></div><small>${escapeHtml(data.time || "Recent AQI.IN scrape")}</small></div></article>`;
      setText("station-count", "1 station"); setText("map-source-state", "AQI.IN LIVE MAP"); setText("map-last-updated", data.time || "Updated from AQI.IN");
      const notice = document.getElementById("map-notice"); if (notice) notice.innerHTML = '<span class="note-mark">i</span><span>AQI.IN source-reported Chandigarh reading. The marker is the city location; no heatmap or interpolation is displayed.</span>';
    } catch (error) {
      setText("map-source-state", "AQI.IN UNAVAILABLE"); setText("station-count", "0 stations");
      const list = document.getElementById("live-station-list"); if (list) list.innerHTML = '<div class="station-list-empty"><span class="empty-list-dash">—</span><p>AQI.IN could not provide a map reading.</p></div>';
      const notice = document.getElementById("map-notice"); if (notice) notice.innerHTML = '<span class="note-mark">!</span><span>AQI.IN is currently unavailable.</span>';
    } finally { if (refresh) refresh.disabled = false; }
  };
  document.getElementById("toggle-stations")?.addEventListener("click", (event) => { if (!observations) return; const on = event.currentTarget.getAttribute("aria-pressed") !== "true"; observations[on ? "addTo" : "removeFrom"](map); event.currentTarget.setAttribute("aria-pressed", String(on)); event.currentTarget.textContent = `Station markers: ${on ? "on" : "off"}`; });
  document.getElementById("refresh-map")?.addEventListener("click", loadAqiIn);
  loadAqiIn();
  window.setInterval(() => { if (!document.hidden) loadAqiIn(); }, 60 * 60 * 1000);
})();
